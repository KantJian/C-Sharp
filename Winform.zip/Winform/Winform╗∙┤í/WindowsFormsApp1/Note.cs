﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WindowsFormsApp1
{
    class Note
    {
        //winform应用程序是一种智能客户端技术，我们可以使用winform应用程序
        //帮助我们获得信息或者传输信息等。


        //属性
        //Name：在后台要获得前台的控件对象，需要使用Name属性。
        //visible：指示一个控件是否可见。
        //Enabled：指示一个控件是否可用。


        //事件：发生了一件事情。
        //注册事件：双击控件注册的都是控件默认被选中的那个事件
        //触发事件：


        //在Main函数当中创建的窗体对象，我们称之位这个窗体应用程序的主窗体。
        //也就意味着，当你将主窗体关闭后，整个应用程序都关闭了。
    }
}
