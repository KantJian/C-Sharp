﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace x跑马灯练习
{
    class Note3
    {
        //跑马灯练习
        //abcde
        //bcdea
        //deabc
        //eabcd
        //abcde
        //string str = "abcde";
        //str=str.Substring(1)+str.Substring(0,1);

        //Timer
        //在指定的时间间隔内做一件指定的事情
    }
}
