﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WW_eLabel控件和TextBox控件
{
    class Note2
    {
        //TextBox控件
        //WordWrap：指示文本框是否换行
        //PasswordChar：让文本框显示一个单一的字符
        //ScollBars：是否显示滚动条
        //事件
        //TextChanged：当文本框中的内容发生改变的时候触发这个事件
    }
}
