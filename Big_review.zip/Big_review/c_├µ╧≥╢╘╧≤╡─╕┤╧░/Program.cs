﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace c_面向对象的复习
{
    class Program
    {
        static void Main(string[] args)
        {
            //1、封装、继承、多态

            Person p = new Person();
            //new关键字：1、在堆中开辟空间 2、在开辟的空间中创建对象 3、调用对象的构造函数
        }
    }
}
