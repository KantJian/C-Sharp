﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace c_面向对象的复习
{
    class Person
    {
        //类
        //字段、属性、构造函数、方法、接口

        //字段：存储数据，访问修饰符应该设置为private私有的。
        //属性：保护字段，对字段的取值和赋值进行限定。
        string _name;
        public string Name
        {
            get { return _name; }
            set { _name = value; }
        }
    }
}
