﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace a_语法复习
{
    class Program
    {
        static void Main(string[] args)
        {
            //1、注释符
            //单行注释 // 注释单行代码
            //多行注释 /* */
            //文档注释///注释类和方法
            //HTML<！--要注释内容-->
            //CSS /*要注释的内容*/

            //使用进程打开指定的文件
            ProcessStartInfo psi = new ProcessStartInfo(@"E:\C#练习2021-8-13\asd.txt");
            Process p = new Process();
            p.StartInfo = psi;
            p.Start();
        }
    }
}

