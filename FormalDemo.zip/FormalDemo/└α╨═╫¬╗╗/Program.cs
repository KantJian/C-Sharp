﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace 类型转换
{
    class Program
    {
        static void Main(string[] args)
        {
            //int n1 = 10;
            //int n2 = 3;
            ////double d = n1 / n2;
            ////整数类型加减乘除取余数还是整数 
            //double d = n1 * 1.0 / n2; // 提升为double类型 
            //Console.WriteLine("{0:0.00}",d);
            //Console.ReadKey();



            //int n1 = 5;
            //int n2 = 2;
            //double d = n1*1.0 / n2;
            //Console.WriteLine(d);
            //Console.ReadKey();

            //小时（Hour） 分钟（Minute） 秒（Seconds）
            //练习1：编程实现计算几天（如46天）是几周零几天？

            //int day1 = 46;
            //double day2 = day1 / 7;
            //double day3 = day1%7;
            //Console.WriteLine("{0}天是{1}周零{2}天",day1,day2,day3);
            //Console.ReadKey();


            //练习2：编程实现107653秒是几天几小时几分钟几秒？
            /* 我写的
            int seconds = 107653;// 一天有86400s    
            int days = seconds / 86400;// 已知秒数除以一天的秒数求得天数
            int secs = seconds % 86400;//已知秒数和一天总秒数取余数能得求完天数后剩余的秒数
            int hours = secs / 3600;//求完天数剩余的秒数除以3600求小时数
            int secs1 = secs % 3600;//求完小时数剩余的秒数                                           
            int minute = secs1 / 60;//求分钟数
            int second = secs1 % 60;//求完分钟数剩余的秒数
            Console.WriteLine("{0}秒是{1}天{2}小时{3}分钟{4}秒",seconds,days,hours,minute,second);
            Console.ReadKey();
            */
            //--------------------------------大佬写的------------------------------  相比较利用变量重复赋值的特征我的可以少生明两个变量
            int seconds = 107653;
            int days = seconds / 86400;//求得天数
            int secs = seconds % 86400;//求得求完天数剩余的秒数
            int hours = secs / 3600;//求得小时数
            secs = secs % 3600; //利用变量能重复赋值的特征--求得小时数后剩余的秒数
            int mins = secs / 60;//求得分钟数
            secs = secs % 60;
            Console.WriteLine("{0}秒是{1}天{2}小时{3}分钟{4}秒", seconds, days, hours, mins, secs);
            Console.ReadKey();




            //练习3：修改上面的题目，让用户输入。


        }
    }
}
