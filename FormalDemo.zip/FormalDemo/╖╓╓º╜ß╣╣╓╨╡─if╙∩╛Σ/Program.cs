﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace 分支结构中的if语句
{
    class Program
    {
        static void Main(string[] args)
        {

            /*
            if语句语法：
                        if（判断条件）
                        {
                           要执行的代码;
                        }
            判断条件：一般为关系表达式或着bool类型的值；
            执行过程：程序运行到if处，首先判断if所带的小括号中的判断条件，
            如果条件成立，也就是返回true，则执行if所带大括号中的代码
            如果判断条件不成立，也就是返回一个false，则跳过if结构，继续向下执行。

            if结构特点：先判断，再执行，有可能一行代码都不执行
            用于一种情况的判断
             */

            //编程实现：如果跪键盘的时间大于60分钟，那么媳妇奖励我晚饭不用做了
            //Console.WriteLine("请输入你跪键盘的时间");
            //int mins = Convert.ToInt32(Console.ReadLine());           
            //bool a = mins > 60;       //                              //如果你想表示的含义是当a的值为true的时候去执行if中的代码，
            //if(a)                     //if（mins>60==true）           //那么 语法上 ==ture可以省略
            //{                                                         //但是，如果你想表示的是当a=false的时候去执行if中的代码，
            //    Console.WriteLine("好老公不用跪了，去吃屎吧");        //语法上 ==false不能省略
            //}
            //Console.ReadKey();

            //练习：
            //1.让用户输入年龄，如果输入的年龄大于23（含）岁，则给用户显示你到了结婚的年龄了
            //Console.WriteLine("请输入您的年龄");
            //int a = Convert.ToInt32(Console.ReadLine());
            //bool b=a >= 23;
            //if(b)
            //{
            //    Console.WriteLine("你到了结婚的年龄");
            //}
            //Console.ReadKey();
            /*2.如果老苏的（chinese music）
                   a.语文成绩大于并且音乐成绩大于80
                   b.语文成绩等于100并且音乐成绩大于70，则奖励100元
            */
            //Console.WriteLine("请输入老苏的语文成绩");
            //double chinese = Convert.ToDouble(Console.ReadLine());
            //Console.WriteLine("请输入老苏的音乐成绩");
            //double music = Convert.ToDouble(Console.ReadLine());
            //bool a = (chinese > 90 && music > 80) || (chinese == 100 && music > 70);
            //if(a)
            //{
            //    Console.WriteLine("奖励100元！！！");
            //}
            //Console.ReadKey();
            //3.让用户输入用户名和密码，如果用户名为admin，密码为mypass，则提示登陆成功
            //Console.WriteLine("请输入用户名");
            //string a = Console.ReadLine();
            //Console.WriteLine("请输入密码");
            //string b = Console.ReadLine();
            //bool c = a == "admin" && b == "mypass";
            //if (c)
            //{
            //    Console.WriteLine("登陆成功！");
            //}
            //Console.ReadKey();

            //------------------------if else-----------------------
            //语法：
            //         if（判断条件）
            /*         {
                            执行的代码         ；            
                        }
                        else
                        {
                            
                        }
            执行过程：程序执行到if处，首先判断if所带的小括号中的判断条件是否成立，
            如果成立，也就是返回一个true，则执行所带的打括号中的代码，
            执行完成后，跳出if-else结构。
            如果if所带的小括号中的判断条件不成立，也就是返回一个false。
            则跳过if语句，执行else所带的大括号中的语句，执行完成后，跳出if-else结构。
            用于两种情况的判断
            */

            //------------if_else练习----------
            //如果小赵的考试成绩大于90（含）分，那么爸爸奖励他100元钱，
            //否则的话，爸爸就让小赵吃屁。
            //Console.WriteLine("请输入小赵的成绩");
            //double grades = Convert.ToDouble(Console.ReadLine());
            //bool a = grades >= 90;
            //if(a)
            //{
            //    Console.WriteLine("奖励100元钱！！！");
            //}
            //else
            //{
            //    Console.WriteLine("吃屁吧0.0");
            //}
            //Console.ReadKey();

            //对学员的结业考试成绩测评
            /*
                成绩>=90   ：A
                90>成绩>80 ：B
                80>成绩>70 ：C
                70>成绩>60 ：D
                60>成绩>50 ：E
            */
            #region 用if else做法学生成绩等级
            Console.WriteLine("请输入学员的成绩");
            double grade = Convert.ToDouble(Console.ReadLine());
            bool a = 80 < grade &&grade<90;
            bool b = 70 < grade && grade < 80;
            bool c = 60 < grade && grade < 70;
            bool d = 50 < grade && grade < 60;
            if(a)
            {
                Console.WriteLine("A级");
            }
            else
            {
                if(b)
                {
                    Console.WriteLine("B级");                                     /////else永远离最近的if配对！！！！！------
                }
                else
                {
                    if(c)
                    {
                        Console.WriteLine("C级");
                    }
                    else
                    {
                        if(d)
                        {
                            Console.WriteLine("E级");
                        }
                    }
                }
            }
            Console.ReadKey();
            #endregion

            //----------------if else-if---------------
            /*
              作用：用来处理多条件的区间性的判断。
              语法：
                    if（判断条件）
                       {
                            要执行的代码；
                       }
                        else if(判断条件)
                       {
                            要执行的代码；
                       }
                        else if(判断条件)
                       {
                            要执行的代码；
                       }
                        else if(判断条件)
                       {
                            要执行的代码；
                       }
                        else if(判断条件)
                       {
                            要执行的代码；
                       }
                       ·········
                       else
                       {
                            要执行的代码；
                       }
            执行过程：程序首先判断第一个if所带的小括号中的判断条件，如果条件成立，
            也就是返回一个true，则执行该if所带的大括号中的代码，执行完成后，立即跳出if else-if结构。
            如果第一个if所带的判断条件不成立，也就是返回一个false，则继续向下进行判断，依次的判断每一个if的判断条件，如果成立，
            就执行if所带的大括号中的代码，如果不成立，则继续往下判断，
            如果每个if所带的判断条件都不成立，就看当前这个if else-if结构中是否存在else。
            如果有else的话，则执行else中所带的代码，如果没有else，则整个if else-if神马都不做。
            else可以省略
            用于多种情况
            */



        }
    }
}
