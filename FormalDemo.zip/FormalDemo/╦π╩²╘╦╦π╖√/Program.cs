﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace 算数运算符
{
    class Program
    {
        static void Main(string[] args)
        {

            /*
               +
               -
               *
               /
               %
            */

            //演示：某学生三门课成绩为，语文：90 数学：80 英语：67，编程求总分和平均分
            //int chinese = 90;
            //int math = 80;
            //int english = 67;
            //Console.WriteLine("三科成绩的总分是{0}，平均分是{1}",chinese+math+english,(chinese+math+english)/3);
            //Console.ReadKey();

            //练习1：定义两个数分别为100和20，打印出两个数的和
            int number1 = 100;
            int number2 = 20;
            Console.WriteLine("两个数的和为{0}", number1 + number2);
            Console.ReadKey();

            //练习2：计算半径为5的圆的面积和周长并打印出来.pi为3.14面积：pi*r*r，Perimeter（周长）
            int r = 5;
            double pi = 3.14;
            Console.WriteLine("面积={0}，周长={1}", pi * r * r, pi * 2 * r);
            Console.ReadKey();

            //练习3：某商店T恤（T-shirt）的价格为35元/件，裤子（trousers）的价格为120元/条，小明在该店买了3件T恤和两条裤子，请计算并显示小明应该付多少钱？
            //       打8.8折后呢？
            int t_Shirt = 35;
            int trousers = 120;
            Console.WriteLine("小明应付{0}元，打完8.8折后应付{1}元",t_Shirt*3+trousers*2,(t_Shirt * 3 + trousers * 2)*0.88);
            Console.ReadKey();


            //类型转换---我们要求等号两边的操作数的类型必须一致，如果不一致，满足下列条件会发生自动类型转换，或者称之为隐式类型转换。
            //1.两种类型兼容 例如：int和double 兼容（都是数字类型）
            //2.目标类型大于源类型 例如： double > int 小的转大的
            //  double转int 是强制类型转换 也叫显示类型转换   
            //显示类型转换：1.两种类型相兼容
            //              2.大类型转小类型 
            double d = 103.6;
            int n = (int)d;
            Console.WriteLine(n);
            Console.ReadKey();

            





        }
    }
}
