﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Assignment_Operators
{
    class Program
    {
        static void Main(string[] args)
        {
            //int n = 50;
            //n = 10;
            //Console.WriteLine(n);
            //Console.ReadKey();


            //string name = "李焕英";
            //Console.WriteLine("你好，"+name);
            //Console.ReadKey();


            //string name = "卡卡西";
            //int age = 30;
            //string email = "kakaxi@qq.com";
            //string address = "火影村";
            //decimal salary = 2000m;
            //Console.WriteLine("我叫"+name +",我住在"+address+",我今年"+age+"，我的邮箱是"+email+"，我的工资是"+salary);
            //Console.ReadKey();



            int age = 18;
            age = 81;
            Console.WriteLine("原来你都"+age+"岁了啊0.0");
            Console.ReadKey();


        }
    }
}
