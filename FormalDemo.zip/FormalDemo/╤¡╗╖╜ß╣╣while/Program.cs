﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace 循环结构while
{
    class Program
    {
        static void Main(string[] args)
        {
            /*
                循环结构
                while循环：
                while（循环条件）
                {
                    循环体；
                }
                执行过程：程序运行到while处，首先判断while所带的小括号内的循环条件是否成立，
                如果成立的话，也就是返回一个true，则执行循环体，执行完一遍循环体后，再次回到
                循环条件进行判断，如果依然成立，则继续执行循环体，如果不成立，则跳出while循环，
                在while循环当中，一般总会有那么一行代码，能够改变循环条件，使之终有一天不再成立，
                如果没有那么一行代码能够改变循环条件，也就是循环条件永远都成立，我们称之这种循环
                叫做死循环。
                最简单的最常用的死循环：
                while（true）
                {
                    
                }
            特点：先判断，再执行，有可能一遍循环都不执行
            */




            //向控制台打印100遍 下次考试我一定要细心
            //循环体：Console.WriteLine（“下次考试我一定细心”）；
            //循环条件：打印的次数小于100遍

            //需要定义一个循环变量用来记录循环的次数 每循环一次，循环变量都应该自身加1
            //int i = 0;
            //while (i < 100) 
            //{
            //    Console.WriteLine("下次考试我一定细心");
            //    i++;//，每循环一次，都要自身加1，否则就是死循环
            //}
            //Console.ReadKey();


            //求1-100之间所有整数的和
            //循环体：累加的过程
            //循环条件：i<=100
            //int i = 1;
            //int sum = 0;
            //while(i<=100)
            //{
            //    sum += i;
            //    i++;
            //}
            //Console.WriteLine(sum);
            //Console.ReadKey();

            //求1-100之间所有偶数的和
            //循环体：累加的过程
            //循环条件：i<=100
            int i = 1;
            int sum = 0;
            while(i<=100)
            {
                if (i % 2 == 0)
                {
                    sum += i;
                }
                i++;
            }
            Console.WriteLine(sum);
            Console.ReadKey();



        }
    }
}
