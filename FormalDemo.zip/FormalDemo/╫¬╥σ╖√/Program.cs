﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace 转义符
{
    class Program
    {
        static void Main(string[] args)
        {
            /*
              \n：表示换行
              \"：表示一个英文半角的双引号
              \t：表示空格 tab键的意思
              \b：表示一个退格键，放到字符串两边没有效果
              \r\n:windows操作系统不认识\n，只认识\r\n （在桌面上）
              \\: 表示一个\
               @: 取消\在字符串中的转义作用； 将字符串按照原格式输出
             */

            //Console.WriteLine("今天天气好晴朗\n处处好春风");


            //Console.WriteLine("我想在这句话中输出一个\"英文半角的双引号");


            //string name1 = "张三";
            //string name2 = "麦尔古拜木合塔尔麦尔菲娜木合塔尔";
            //string name3 = "阿斯顿卡仕达卡仕达大家";
            //string name4 = "艾什莉多久啊利口酒热辣爱伦坡其二军委";
            //Console.WriteLine("{0}\t\t\t{1}", name1, name2);
            //Console.WriteLine("{0}\t{1}", name3, name4);


            // Console.WriteLine("学习编\b程有用吗？学了不一定会，会了不一定找得到工作，找到工作不一定能买得起房子，买得起房子不一定娶得到老婆，娶得到老婆不一定生得起孩子，生的起孩子孩子不一定是你\b的");


            //Console.ReadKey();

            //string path = @"";
            //char c = '\b'; //  \在里面起到了一个转义的作用

            //Console.WriteLine(@"今天天气好晴朗
            //处处好春风");
            //Console.ReadKey();


        }
    }
}
