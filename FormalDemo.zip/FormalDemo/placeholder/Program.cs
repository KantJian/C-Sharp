﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace placeholder
{
    class Program
    {
        static void Main(string[] args)
        {
            //占位符  先挖一个坑 再填一个坑
            //int n1 = 10;
            //int n2 = 20;
            //int n3 = 30;
            ////Console.WriteLine("第一个数字是："+n1+"，第二个数字是："+n2+"，第三个数字是："+n3);
            //Console.WriteLine("第一个数字是:{0}，第二个数字是:{1}，第三个数字是:{2}",n1,n2,n3);//占位符按照挖坑的顺序输出
            //Console.ReadKey();


            //string name = "x";
            //char gender = 'x';
            //string age = "x";
            //string telephoneNumber = "xxxx";
            //Console.WriteLine("我叫{0}，我今年{1}岁了,我是{2}生,我的电话号是{3}",name,gender,age,telephoneNumber);
            //Console.ReadKey();


            //定义两个变量如：number1,number2分别赋值为10和5,写程序交换两个变量的值
            /*
             int number1 = 10;
             int number2 = 5;
             int temp = number1;
             number1 = number2;
             number2 = temp;
             Console.WriteLine("交换后，number1和number2的值分别为{0}和{1}",number1,number2);
             Console.ReadKey();
            */


            //请交换两个int类型的变量，要求：不使用第三方的变量

            int n1 = 10;
            int n2 = 20;
            //n1=20 n2=10

            n1 = n1 - n2;//n1=-10 n2=20
            n2 = n1 + n2;//n1=-10 n2=10
            n1 = n2 - n1;
            Console.WriteLine("交换后，n1的值是{0}，n2的值是{1}",n1,n2);
            Console.ReadKey();




        }
    }
}
