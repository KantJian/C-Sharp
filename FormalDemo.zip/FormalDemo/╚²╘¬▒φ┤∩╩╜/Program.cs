﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace 三元表达式
{
    class Program
    {
        static void Main(string[] args)
        {
            //三元表达式
            /*语法：
             * 表达式1？表达式2：表达式3；
             * 表达式1一般为一个关系表达式。
             * 如果表达式1的值为true，那么表达式2的值就是整个三元表达式的值。
             * 如果表达式1的值false，那么表达式3的值就是整个三元表达式的值。
             * 注意：表达式2的结果类型必须跟表达式3的结果类型一致，并且也要跟整个三元表达式的结果类型一致。
             * 一般if else 能做的三元表达式也可以
            */


            //计算两个数字的大小 求出最大的
            //Console.WriteLine("请输入第一个数字");
            //int numberOne = Convert.ToInt32(Console.ReadLine());
            //Console.WriteLine("请输入第二个数字");
            //int numberTwo = Convert.ToInt32(Console.ReadLine());
            //int max= numberOne > numberTwo ? numberOne : numberTwo;
            //Console.WriteLine(max);
            ////if(numberOne>numberTwo)
            ////{
            ////    Console.WriteLine(numberOne);
            ////}
            ////else
            ////{
            ////    Console.WriteLine(numberTwo);
            ////}
            //Console.ReadKey();

            //提示用户输入一个姓名 只要输入的不是老赵 就全是流氓
            //Console.WriteLine("请输入姓名");
            //string name = Console.ReadLine();
            //string result = name == "老赵" ? "牲口" : "流氓";
            //Console.WriteLine(result);
            //Console.ReadKey();






        }
    }
}
