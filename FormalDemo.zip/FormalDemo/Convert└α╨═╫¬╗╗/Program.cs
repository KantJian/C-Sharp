﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Convert类型转换
{
    class Program
    {
        static void Main(string[] args)
        {
            //convert转换 面儿上要过得去
            //string s = ("123");
            //double d = Convert.ToDouble(s);
            //int n = Convert.ToInt32(s);
            //Console.WriteLine(d);
            //Console.WriteLine(n);
            //Console.ReadKey();


            //练习：让用户输入姓名 语文数学英语三门课成绩，然后给用户提示：xx，你的总成绩为xx分，平均成绩为xx分；
            //------------我写的---------------
            //Console.WriteLine("请输入你的姓名");
            //string name = Console.ReadLine();
            //Console.WriteLine("请输入你的语文成绩");
            //string cGrades = Console.ReadLine();
            //int cGrades1 = Convert.ToInt32(cGrades);
            //Console.WriteLine("请输入你的数学成绩");
            //string mGrades = Console.ReadLine();                               //double更好成绩不一定为整数
            //int mGrades1 = Convert.ToInt32(mGrades);
            //Console.WriteLine("请输入你的英语成绩");
            //string eGrades = Console.ReadLine();
            //int eGrades1 = Convert.ToInt32(eGrades);
            //int total = cGrades1 + mGrades1 + eGrades1;
            //int average = total / 3;
            //Console.WriteLine("{0}，你的总成绩为{1}分，平均成绩为{2}分", name, total, average);
            //Console.ReadKey();
            //string 相加是 55 77 88  557788 最终会变成相连接 如果要拿字符串类型的变量参与计算需要将字符串转换成int或double类型

            //-------------------double number = Convert.ToDouble(Console.ReadLine());---------------------又可以少定义一个变量





        }
    }
}
