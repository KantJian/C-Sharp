﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace @continue
{
    class Program
    {
        static void Main(string[] args)
        {

            //while(true)
            //{
            //    Console.WriteLine("Hello World");
            //    //break;
            //    continue;
            //    Console.WriteLine("Hello World");
            //    Console.WriteLine("Hello World");
            //}
            //Console.ReadKey();

            #region 练习1
            //练习1：用while continue实现计算1到100（含）之间的除了能被7整除之外所有整数的和。
            //int sum = 0;
            //int i = 1;
            //while(i<=100)
            //{
            //    if (i % 7 == 0)
            //    {
            //        i++;
            //        continue;
            //    }
            //        sum += i;
            //        i++;
            //}
            //Console.WriteLine(sum);
            //Console.ReadKey(); 
            #endregion

            //找出100内所有的质数
            //素数/质数：大于1的自然数，只能被1和这个数字本身整除的数字 //1不是质数
            //2 3 5 7 
            for (int i = 2; i <= 100; i++)
            {
                bool a = true;
                for (int j = i - 1; j >= 2; j--)
                {
                    if (i % j == 0)//如果i%j==0 那么这个数字i就不是质数

                    {
                        a = false;
                        break;
                    }
                    
                }
                if (a)
                {
                    Console.WriteLine("{0}是质数", i);

                }
            }
            Console.ReadKey();

            //第二种方法 // ...差不多....
            //for (int i=2 ;i<=100;i++)
            //{
            //    bool a = true;
            //    for (int j = 2; j < i; j++)
            //    {
            //        if(i%j==0)
            //        {
            //            a = false;
            //            break;
            //        }
            //    }
            //    if (a)
            //    {
            //        Console.WriteLine(i);
            //    }
            //}
            //Console.ReadKey();







        }
    }
}
