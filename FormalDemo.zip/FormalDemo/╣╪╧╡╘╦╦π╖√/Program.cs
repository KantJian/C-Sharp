﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace 关系运算符
{
    class Program
    {
        static void Main(string[] args)
        {
            //  1. >,< , ==,!=,>=,<=
            //  关系运算符是用来描述两个事物之间的关系
            //  由运算符连接的表达式称之为关系表达式
            //  bool类型： 在我们c#中我们用bool类型来描述对或者错。 bool类型的值只有两个 一个true 一个false
            /*
                2.逻辑运算符：  && 逻辑与
                              || 逻辑或
                              ！逻辑非
                由逻辑运算符连接的表达式叫做逻辑表达式

                逻辑运算符两边放的一般都是关系表达式或者bool类型的值。
                5 > 3 && true   逻辑与表达式
                3 >5  || false  逻辑表达式
                                逻辑非表达式
                ！表达式  feizhenjijiafeijiajizhen

                逻辑表达式的结果同样也是bool类型
                3.复合赋值运算符 += -+ *= /= %=    是二元运算符
                              int number = 10；
                              number+=20；  即number= number + 20；
             */

            //练习：让用户输入老苏的语文和数学成绩，输出以下判断是否正确，正确输出True，错误输出False
            //        1）老苏的语文和数学成绩都大于90分
            //        2）语文和数学有一门是大于90分的
            // 1)
            //Console.WriteLine("请输入老苏的语文成绩");
            //double cGrades = Convert.ToDouble(Console.ReadLine());
            //Console.WriteLine("请输入老苏的数学成绩");
            //double mGrades = Convert.ToDouble(Console.ReadLine());
            //double a = cGrades;
            //double b = mGrades;
            //bool c = cGrades > 90 && mGrades > 90;
            //Console.WriteLine(c);
            //Console.ReadKey();

            // 2)
            Console.WriteLine("请输入老苏的语文成绩");
            double cGrades = Convert.ToDouble(Console.ReadLine());
            Console.WriteLine("请输入老苏的数学成绩");
            double mGrades = Convert.ToDouble(Console.ReadLine());
            double a = cGrades;
            double b = mGrades;
            bool c = cGrades > 90 || mGrades > 90;
            Console.WriteLine(c);
            Console.ReadKey();












        }
    }
}
