﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace 类型转换int.pase
{
    class Program
    {
        static void Main(string[] args)
        {
            //使用convert进行转换，成功了就成功了，失败了就抛异常
            //int numberOne = Convert.ToInt32("123abc");

            //int number = int.Parse("123abc");
            //Console.WriteLine(number);              //toint32实质上调用int.parse  所以int.parse效率高 但可忽略不计
            //Console.ReadKey();

            /*int.TryParse
             * 尝试着将一个字符串转换成int类型。
             * 出现错误不抛异常  性能相对于上面两个高一些
             * 在我们c#中称为方法 ，c#中方法就是函数函数就是方法，同一种东西
            */

            int number = 0;
            //bool类型  --参数 返回值
            bool b=int.TryParse("123abc",out number);  // 括号里面的两个变量叫做参数，bool类型的变量叫做参数的返回值
            Console.WriteLine(b);      // // 如果转换成功把值给number并且返回一个true表示转换成功，失败就返回一个false并且number为0 
            Console.WriteLine(number);
            //方法 或者 函数 ？       
            //方法就是帮我们做一件事
            Console.ReadKey();




        }
    }
}
