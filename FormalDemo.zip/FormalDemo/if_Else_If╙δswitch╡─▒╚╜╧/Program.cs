﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace if_Else_If与switch的比较
{
    class Program
    {
        static void Main(string[] args)
        {

            /*
              相同点：都可以实现多分支结构
              不同点：if-else if：可以处理范围 对区间判断
              switch：一般只能与等值比较 对定值判断

            */

            #region 对学员的结业考试成绩测评
            /*
                    成绩>=90   ：A
                    90>成绩>80 ：B
                    80>成绩>70 ：C
                    70>成绩>60 ：D
                    60>成绩>50 ：E
                */

            //Console.WriteLine("请输入一个考试成绩");
            //int score=Convert.ToInt32(Console.ReadLine());//0-100
            //switch(score/10) //你要把范围   变成一个定值
            //{
            //    case 10:
            //    case 9: Console.WriteLine("A");  //case10和case后面代码完全一样可以省略
            //        break;
            //    case 8: Console.WriteLine("B");
            //        break;
            //    case 7: Console.WriteLine("C");
            //        break;
            //    case 6: Console.WriteLine("D");
            //        break;
            //    default: Console.WriteLine("E");
            //        break;
            //}
            //Console.ReadKey(); 
            #endregion

            //请用户输年份，再输入月份，输出该月的天数。（结合之前如何判断闰年来做）
            //年份能够被400整除.（2000）  year%400==0；
            //年份能够被4整除但不能被100整除.（2008） year%4==0&&year%100！=0；

            try
            {
                Console.WriteLine("请输入年份");
                int year = Convert.ToInt32(Console.ReadLine()); // 用户输入年份 然后接受
                try
                {
                    Console.WriteLine("请输入月份");
                    int month = Convert.ToInt32(Console.ReadLine());// 用户输入月份 然后接受
                    if (month >= 1 && month <= 12)
                    {
                        switch (month) //只有2月份的天数  受闰年的影响 闰年2月29天 此外28天
                        {
                            case 1:
                            case 3:
                            case 5:
                            case 7:
                            case 8:
                            case 10:
                            case 12:
                                Console.WriteLine("该月有31天");
                                break;
                            case 2:
                                if ((year % 400 == 0) || (year % 4 == 0 && year % 100 != 0))
                                {
                                    Console.WriteLine("该月有29天");
                                }
                                else
                                {
                                    Console.WriteLine("该月有28天");
                                }
                                break;
                            default:
                                Console.WriteLine("该月有30天");
                                break;
                        }
                    }
                    else
                    {
                        Console.WriteLine("输入的月份不存在");
                    }
                }
                catch 
                {
                    Console.WriteLine("输入的月份有误");
                }
            }
            catch
            {
                Console.WriteLine("输入年份格式不对");
            }
            Console.ReadKey();



        }
    }
}
