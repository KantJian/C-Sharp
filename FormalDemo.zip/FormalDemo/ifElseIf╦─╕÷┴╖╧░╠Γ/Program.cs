﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ifElseIf四个练习题
{
    class Program
    {
        static void Main(string[] args)
        {
            ////比较3个数字的大小 不考虑相等
            ////分别提示用户输入三个数字 并接受转换成int类型
            //Console.WriteLine("请输入第一个数字");
            //int number1 = Convert.ToInt32(Console.ReadLine());
            //Console.WriteLine("请输入第二个数字");
            //int number2 = Convert.ToInt32(Console.ReadLine());
            //Console.WriteLine("请输入第三个数字");
            //int number3 = Convert.ToInt32(Console.ReadLine());
            ////--
            //if (number1 > number2 && number2 > number3)
            //{
            //    Console.WriteLine("{0}>{1}>{2}",number1,number2,number3);
            //}
            //else if (number1 > number3 && number3>number2)
            //{
            //    Console.WriteLine("{0}>{1}>{2}",number1,number3,number2);
            //}
            //else if(number2>number1&&number1>number3)
            //{
            //    Console.WriteLine("{0}>{1}>{2}",number2,number1,number3);
            //}
            //else if (number2 > number3 && number3 > number1)
            //{
            //    Console.WriteLine("{0}>{1}>{2}", number2, number3, number1);
            //}
            //else if (number3 > number1 && number1 > number2)
            //{
            //    Console.WriteLine("{0}>{1}>{2}", number3, number1, number2);
            //}
            //else if (number3 > number2 && number2 > number1)
            //{
            //    Console.WriteLine("{0}>{1}>{2}", number3, number2, number1);
            //}
            //Console.ReadKey();  



            ////练习1：提示用户输入密码，如果密码是“888888”则提示正确，否则要求再输入一次，
            ////如果密码是“88888”则提示正确，否则提示错误，程序结束。
            ////（如果我的密码里有英文还要转换吗，密码：abc1）

            //Console.WriteLine("请输入密码");
            //string pwd = Console.ReadLine();
            //if(pwd=="888888")
            //{
            //    Console.WriteLine("密码正确！");
            //}
            //else
            //{
            //    Console.WriteLine("密码错误！请重新输入");
            //    pwd = Console.ReadLine();
            //    if(pwd=="888888")
            //    {
            //        Console.WriteLine("输了两遍，终于输对了");
            //    }
            //    else
            //    {
            //        Console.WriteLine("两遍都不对，程序结束");
            //    }
            //}
            //Console.ReadKey();

            //练习2：提示用户输入用户名，然后再提示输入密码，如果用户名是“admin”并且密码是“888888”，
            //则提示正确，否则，如果用户名不是admin还提示用户用户名不存在，
            //如果用户名是admin，则提示密码错误。
            #region 自己写的垃圾*-*
            //Console.WriteLine("请输入用户名");
            //string name = Console.ReadLine();
            //if(name=="admin")
            //{
            //    Console.WriteLine("请输入密码");
            //}
            //else//用户名不是admin提示用户不存在
            //{
            //    Console.WriteLine("用户名不存在");
            //}
            //string pwd = Console.ReadLine();
            // if(pwd=="888888")
            //{
            //    Console.WriteLine("登陆成功！");
            //}
            //else
            //{
            //    Console.WriteLine("密码错误");
            //}
            //Console.ReadKey();
            #endregion

            //Console.WriteLine("请输入用户名");
            //string name = Console.ReadLine();
            //Console.WriteLine("请输入密码");
            //string pwd = Console.ReadLine();
            //if(name!="admin")
            //{
            //    Console.WriteLine("用户名不存在");
            //}
            //else if(pwd!="888888")
            //{
            //    Console.WriteLine("密码错误");
            //}
            //else
            //{
            //    Console.WriteLine("登陆成功！");
            //}
            //Console.ReadKey();


            //练习3：提示用户输入年龄，如果大于等于18，则告知用户可以查看，如果小于18岁，
            //则告知不允许查看，如果大于等于10岁并且小于18，
            //则提示用户是否继续查看（yes no），如果输入的是yes则提示用户请查看，
            //否则提示“退出，你放弃查看”。

            Console.WriteLine("请输入年龄");
            int age = Convert.ToInt32(Console.ReadLine());
            if( age >= 18)
            {
                Console.WriteLine("可以查看");
            }
            else if(age>=10)
            {
                Console.WriteLine("不允许查看，是否继续查看？yes/no");
                string ans = Console.ReadLine();
                if (ans == "yes")
                {
                    Console.WriteLine("请查看");
                }
                else
                {
                    Console.WriteLine("退出，你放弃查看");
                }
            }
            else
            {
                Console.WriteLine("不允许查看");
            }
            Console.ReadKey();







        }
    }
}
