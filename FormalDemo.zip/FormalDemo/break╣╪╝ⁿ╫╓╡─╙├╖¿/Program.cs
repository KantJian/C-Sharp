﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace break关键字的用法
{
    class Program
    {
        static void Main(string[] args)
        {

            //break
            /*
                1.可以跳出switch-case结构
                2.跳出当前while循环
            break一般不单独的使用，而是跟着if判断一起使用，表示，当满足某些条件的时候，就不再循环了。
            */


            //int i = 1;
            //int j = 1;
            //while (i <= 10)
            //{
            //    while (j <= 10)
            //    {
            //        Console.WriteLine("Hello World");
            //        j++;
            //        break;
            //    }
            //    Console.WriteLine("我是外面的循环");
            //    i++;
            //}
            //Console.ReadKey();

            //练习题
            // 输入班级人数，然后依次输入学员成绩，计算班级学员的平均成绩和总成绩

            //循环体：输入学员的成绩  学员成绩相加
            //循环条件：<=班级人数0
            #region 泪目 写了一小时*-*我是fw
            Console.WriteLine("输入班级人数");
            int people = Convert.ToInt32(Console.ReadLine());
            int i = 1;
            int j = 1;
            int sum = 0;//总成绩
            int avg = 0;//平均成绩
            int grades = 0;
            while (j <= people)
            {
                while (i <= people)
                {
                    i++;
                    Console.WriteLine("请依次输入学生的成绩");
                    grades = Convert.ToInt32(Console.ReadLine());
                    break;
                }
                sum += grades;
                j++;
            }
            avg = sum / people;
            Console.WriteLine("该班级学生总成绩为{0}", sum);
            Console.WriteLine("该班级学生的平均成绩为{0}", avg);
            Console.ReadKey();
            #endregion

            /* 老师问学生，这道题你会做了吗？如果学生回答“会了（y）”，则可以放学，如果学生回答“不会（n）”，则老师
             * 在讲一遍，再问学生是否做回了......
             * -----直到学生会为止，才可以放学.
             * -----直到学生会或老师给他讲了10遍还不会,都要放学
             */
            //循环体：重复讲课
            //循环条件：讲的次数<=10
            #region 有内味儿了
            //int i = 1;//讲课次数
            //bool a=true;
            //Console.WriteLine("这道题你会做了吗？");
            //string answer =Console.ReadLine();
            //if(answer=="y")
            //{
            //    Console.WriteLine("可以放学了！！！");
            //    a =false;
            //}
            //else
            //{
            //    while(i<=10)
            //    {
            //        Console.WriteLine("讲了{0}遍，这道题你会做了吗？",i);
            //        answer = Console.ReadLine();
            //        if(answer=="y")
            //        {
            //            break;
            //        }
            //        i++;
            //    }
            //}
            //if(a)
            //Console.WriteLine("放学！！！");
            //Console.ReadKey(); 
            #endregion

            // 2006年培养学员80000人，每年增长25%，请问按此增长速度，到哪一年培训学员人数将达到20万人？
            //循环体：人数增长
            //循环条件：培训学院人数达到20万人
            #region so easy
            //2006年  80000人
            //每年增长25%  2007年=80000+80000*0.25
            //int year = 2006;
            //double number = 80000;//年份和成员初始值
            //while(number<200000)
            //{
            //    year++;
            //    number = number + number * 0.25;
            //}
            //Console.WriteLine(year);
            //Console.ReadKey();
            #endregion







        }
    }
}
