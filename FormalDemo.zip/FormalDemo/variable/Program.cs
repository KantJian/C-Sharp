﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace variable
{
    class Program
    {
        static void Main(string[] args)
        {
            //变量类型 变量名;
            //变量名 =值;
            //100

            //官方语言：声明或者定义一个int类型的变量
            //int number;//在内存中开辟了一块能够存储整数的空间
            //           //官方语言：给这个变量进行赋值
            //number = 100;//表示把100存储到了这块空间内
            //上两行也可以写成 int n = 100;



            //char单引号 string双引号 double int decimal  

            //变量的使用规则
            int number;//声明或者定义了整数类型的变量
            number = 20;
            Console.WriteLine(number);
            Console.ReadKey();

            string ss = "sa";
            //String s = "asd";
            

        }
    }
}
