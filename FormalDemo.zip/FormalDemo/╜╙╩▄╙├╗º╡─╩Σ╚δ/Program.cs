﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace 接受用户的输入
{
    class Program
    {
        static void Main(string[] args)
        {
            //Console.WriteLine("请输入你的名字");
            //string name = Console.ReadLine();
            //Console.WriteLine("你的名字是{0}",name);
            //Console.ReadKey();


            //1.练习：问用户喜欢吃什么水果（fruits），假如用户输入“苹果”，则显示“哈哈，这么巧，我也喜欢吃苹果”；
            //Console.WriteLine("你喜欢吃什么水果？");
            //string fruite = Console.ReadLine();   不管接受什么数字还是字母都只能存string
            //Console.WriteLine("哈哈，这么巧，我也喜欢吃{0}", fruite);
            //Console.ReadKey();


            //2.请用户输入姓名性别年龄，当用户按下回车后在屏幕上显示：您好：xx 您的年龄是xx 是个x生 
            Console.WriteLine("请输入您的姓名");
            string name = Console.ReadLine();
            Console.WriteLine("请输入您的性别");
            string gender = Console.ReadLine();
            Console.WriteLine("请输入您的年龄");
            string age = Console.ReadLine();
            Console.WriteLine("您的姓名是{0}，{1}生，年龄是{2}岁",name,gender,age);
            Console.ReadKey();
            
        }
    }
}
