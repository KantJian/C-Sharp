﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace 异常捕获
{
    class Program
    {
        static void Main(string[] args)
        {
            //语法上没有错误，在程序运行的过程当中，由于某些原因程序出现了错误，不能再正常的运行

            //1.异常捕获
            //我们的程序中经常会出现各种各样的异常，你如果想要你的程序变得坚强一些。
            //在你的代码中应该经常性的使用try-catch来进行异常捕获。

            //哪行代码有可能出现异常，你就踹他一脚。
            //语法：
            /*try
             {
                 可能会出现异常的代码；
                 ··········；
                 ··········；
                 ··········；
             }
             //try和catch之间不能有其他的代码
            catch                                                       
            {
                 出现异常后执行的代码；
            }

            执行过程：如果try中的代码没有出现异常，那么catch中的代码不会执行。
            如果try中的代码出现异常，哪怕这行出现异常的代码后面还有一百行都不会执行了，
            而是直接跳到catch中执行代码
            */
            //2.变量的作用域
            /*变量的作用域就是你能够使用到这个变量的范围。
             *变量的作用域一般从声明它的那个括号开始到那个括号所对应的结束的括号结束。
             *在这个范围内，我们可以访问并使用变量。超出这个范围就访问不到了
            */



            bool b = true;
            int number = 0;//声明一个变量
            Console.WriteLine("请输入一个数字");
            try
            {
                //abc
                number = Convert.ToInt32(Console.ReadLine());
            }
            catch
            {
                Console.WriteLine("输入的内容不能转换成数字");
                b = false;
            }
            //我们如果要执行下面这行代码，需要满足哪些条件。
            //让代码满足某些条件去执行的话，使用bool类型
            if(b)
            {
                Console.WriteLine(number*2);//使用
            }
            Console.ReadKey();





        }
    }
}
