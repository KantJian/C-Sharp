﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace switch_Case
{
    class Program
    {
        static void Main(string[] args)
        {


            #region 练习题------用了try catch*-*做练习练了练，但只用booltrueflase就能写的更简洁
            //李四的年终工作评定，如果定位A级，则工资涨500元，如果定为B级，
            //则工资涨200元，如果定为C，工资不变，如果定为D级工资降200元，
            //如果定为E级工资降500元，
            //设李四的原工资为5000元，请用户输入李四的评级，然后显示李四来年的工资

            //decimal first = 5000m;
            //decimal money = 0m;
            //char rate = '0';
            //bool a = true;
            //Console.WriteLine("请输入李四的评级");
            //try
            //{
            //    rate = Convert.ToChar(Console.ReadLine());
            //}
            //catch
            //{
            //    Console.WriteLine("输入的评级为错误评级");
            //    a = false;
            //}
            //if (rate == 'A')
            //{
            //    money = 5000 + 500;
            //}
            //else if (rate == 'B')//不是A级进入此段程序
            //{
            //    money = 5000 + 200;
            //}
            //else if (rate == 'C')//不是A、B
            //{
            //    money = first;
            //}
            //else if (rate == 'D')//不是A、B、C
            //{
            //    money = 5000 - 200;
            //}
            //else if (rate == 'E')//不是A、B、C、D
            //{
            //    money = 5000 - 500;
            //}
            //else
            //{
            //    Console.WriteLine("输入的评级为错误评级");
            //    a = false;
            //}
            //if (a)
            //{
            //    Console.WriteLine("李四来年的工资为{0}", money);
            //}
            //Console.ReadKey();
            #endregion

            #region switch-case
            //switch-case
            //用来处理多条件的定值的判断。
            //语法：
            /*switch(变量或者表达式的值)
            {
                case 值1: 要执行的代码;
                break;
                case 值2: 要执行的代码;
                break;
                case 值2: 要执行的代码;
                break;
                ······
                default:  要执行的代码;
                break;

             }

            执行过程;程序执行到switch处，首先将括号中变量或者表达式的值计算出来，
            然后拿着这个值依次跟每个case后面所带的值进行匹配，一旦匹配成功，则执行
            该case所带的代码，执行完成后，遇到break。跳出switch-case结构。
            如果，跟每个case所带的值都不匹配。就看当前这个switch-case结构中是否存在
            default，如果有default，则执行default中的语句，如果没有default，则该switch-case结构什么都不做。
             */
            #endregion

            //李四的年终工作评定，如果定位A级，则工资涨500元，如果定为B级，
            //则工资涨200元，如果定为C，工资不变，如果定为D级工资降200元，
            //如果定为E级工资降500元，
            //设李四的原工资为5000元，请用户输入李四的评级，然后显示李四来年的工资
            //---------再做一遍比较两种方法

            #region if else-if做法
            //Console.WriteLine("请输入张静的工作评级");
            //int salary = 5000;
            //bool a = true;
            //string level = Console.ReadLine();
            //if (level == "A")
            //{
            //    salary += 500;
            //}
            //else if (level == "B")
            //{
            //    salary += 200;
            //}
            //else if (level == "C")
            //{

            //}
            //else if (level == "D")
            //{
            //    salary -= 200;
            //}
            //else if (level == "E")
            //{
            //    salary -= 500;
            //}
            //else
            //{
            //    Console.WriteLine("输入有误，程序退出");
            //    a = false;
            //}
            //if (a)
            //    Console.WriteLine("李四来年的工资是{0}", salary);
            //Console.ReadKey(); 
            #endregion

            #region switch case做法
            //int salary = 5000;
            //bool a = true;
            //Console.WriteLine("请输入李四的工作评级");
            //string level = Console.ReadLine();
            //switch (level)
            //{
            //    case "A":
            //        salary += 500;
            //        break;
            //    case "B":
            //        salary += 200;
            //        break;
            //    case "C": break;
            //    case "D":
            //        salary -= 200;
            //        break;
            //    case "E":
            //        salary -= 500;
            //        break;
            //    default:
            //        Console.WriteLine("输入有误，程序退出");
            //        a = false;
            //        break;
            //}
            //if (a)
            //{
            //    Console.WriteLine("李四明年的工资是{0}元", salary);
            //}
            //Console.ReadKey(); 
            #endregion

            //练习：用户输入姓名，然后显示出这个人上辈子是什么职业。
            Console.WriteLine("请输入一个姓名，我们将显示出来这个人上辈子的职业");
            string name=Console.ReadLine();
            //老杨、老苏、老马、老蒋、老牛、老虎、老赵
            switch(name)
            {
                case "老杨": Console.WriteLine("上辈子是抽大烟的");
                    break;
                case "老苏": Console.WriteLine("上辈子是个卖菜的");
                    break;
                case "老马": Console.WriteLine("上辈子是老苏手下的员工");
                    break;
                case "老蒋": Console.WriteLine("上辈子是做饭的");
                    break;
                case "老牛": Console.WriteLine("上辈子是一坨翔");
                    break;
                case "老虎": Console.WriteLine("上辈子是个大病猫");
                    break;
                case "老赵": Console.WriteLine("上辈子是光芒万丈救苦救难的菩萨呀");
                    break;
                default: Console.WriteLine("不认识，估计是坨");
                    break;
            }
            Console.ReadKey();






        }
    }
}
