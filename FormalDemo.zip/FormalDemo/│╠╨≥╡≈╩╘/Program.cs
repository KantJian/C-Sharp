﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace 程序调试
{
    class Program
    {
        static void Main(string[] args)
        {
            /*
                  程序调试
                  1）、写完一段程序后，想看一下这段程序的执行过程。
                  2）、当你写完这段程序后，发现，程序并没有按照你想象的样子去执行。

                  调试方法：
                  1）、F11逐语句调试（单步调试）
                  2）、F10逐过程调试
                  3）、断点调试                 
            */

            /*
                  断点调试           
                
              
              
             
            */









        }
    }
}
