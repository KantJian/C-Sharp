﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace for循环
{
    class Program
    {
        static void Main(string[] args)
        {
            //向控制台打印10遍 欢迎光临
            //int i = 0;
            //while(i<=10)
            //{
            //    Console.WriteLine("欢迎光临");
            //    i++;
            //}
            //Console.ReadKey();

            //对于这种已知循环次数的
            //for循环
            //语法：
            //for（表达式1；表达式2；表达式3；）
            //{
            //    循环体；
            //}
            //表达式1一般为声明循环变量,记录循环的次数（int i=0;）
            //表达式2一般为循环条件（i<10）
            //表达式3一般为改变循环条件的代码，是循环条件终有一天不再成立（i++）

            //for (int i = 0; i < 10; i++)
            //{
            //    Console.WriteLine("欢迎光临");
            //}
            //Console.ReadKey();

            //执行过程：程序首先执行表达式1，声明了一个循环变量用来记录循环的次数，
            //然后执行表达式2，判断循环条件是否成立，如果表达式2返回的结果为true，
            //则执行循环体。当执行完循环体后，执行表达式3，然后执行表达式2继续判断循环条件是否成立，
            //如果成立则继续执行循环体，如果不成立，则跳出for循环。

            //找出100-900间的水仙花数
            //水仙花数指的就是 这个百位数字的
            //百位的立方+十位的立方+个位的立方==当前这个百位数字
            //153 1 125 27 153 i
            //百位：153/100
            //十位：153%100/10
            //个位：153%10

            #region 水仙花数
            //for (int i = 100; i <=999; i++)
            //{
            //    int bai = i / 100;
            //    int shi = i % 100 / 10;
            //    int ge = i % 10;
            //    if(bai*bai*bai+shi*shi*shi+ge*ge*ge==i)
            //    {
            //        Console.WriteLine("水仙花数有{0}",i);
            //    }
            //}
            //Console.ReadKey();
            #endregion

            //for循环的嵌套

            //int count = 0;
            //for (int i = 0; i < 10; i++)
            //{
            //    for (int j = 0; j < 10; j++)
            //    {
            //        Console.WriteLine("Hello World");
            //        count++;
            //    }
            //}
            //Console.WriteLine(count);
            //Console.ReadKey();

            #region 乘法口诀表
            //for (int i = 1; i < 10; i++)
            //{
            //    for (int j = 1; j < 10; j++)
            //    {
            //        int multiply = i * j;
            //        if (j > i)
            //        {
            //            break;
            //        }
            //        else
            //        {
            //            Console.Write("{0}*{1}={2}\t", i, j, multiply);
            //        }
            //    }
            //    Console.WriteLine();
            //}
            //Console.ReadKey();
            #endregion

            //让用户输入一个数显示下面内容
            /* 请输入一个值：6
             * 根据这个值可以输出以下加法表：
               0 + 6 = 6
               1 + 5 = 6
               2 + 4 = 6
               3 + 3 = 6
               4 + 2 = 6
               5 + 1 = 6
               6 + 0 = 6
            */

            Console.WriteLine("请输入一个数");
            int num = Convert.ToInt32(Console.ReadLine());
            for (int i = 0; i < 10; i++)
            {
                for (int j = 0; j < 10; j++)
                {
                    if (i + j == num)
                    {
                        Console.WriteLine("{0}+{1}={2}",i,j,num);
                    }
                }
            }
            Console.ReadKey();



        }
    }
}
