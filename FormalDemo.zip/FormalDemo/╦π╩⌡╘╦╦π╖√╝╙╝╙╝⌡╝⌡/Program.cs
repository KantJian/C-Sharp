﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace 算术运算符加加减减
{
    class Program
    {
        static void Main(string[] args)
        {
            /*
               ++:分为前++和后++，不管是前++还是后++，最终的结果都是给这个变量加一。
               --:同上
               区别表现表达式当中，如果是前++，则先给这个变量加一，然后带着这个加一后的值去参与运算。
               如果是后++，则先拿原值参与运算，运算完成后，再讲这个变量自身加一。
               
               对于向++或者--这样只需要一个操作数就能完成的运算，我们称之为一元运算符。
               number++；    number--；  number就是一个操作数。
               + - * / %  对于这些需要两个或以上才能完成运算的操作符，我们称之为二元运算符。
               一元运算符的优先级要高于二元运算符；
               如果在一个表达式中，既有一元运算符，又有二元运算符，我们首先计算一元运算符。
               int number = 10；
               int result = 10 + ++number；
            */
            //int number = 10;
            ////number++;
            //++number;//number=number+1;
            ////number--;
            //--number;
            //Console.WriteLine(number);
            //Console.ReadKey();

            //int number = 10;
            //int result = 10 + number++;
            //int result = 10 + number++;
            //number++;


            //int result = 10+ ++number;
            //number++;
            //int result = 10 + number;
            //Console.WriteLine(number);
            //Console.WriteLine(result);
            //Console.ReadKey();


            //int result = 10 + number--;
            //int result = 10 + number;
            //number--;

            // int result = 10 + --number;
            //number--;
            //int result = 10 + number;
            //Console.WriteLine(number);
            //Console.WriteLine(result);
            //Console.ReadKey();

            int a = 5;
            int b = a++ + ++a * 2 + --a + a++;
            //5+7*2+6+6   7
            Console.WriteLine(a);
            Console.WriteLine(b);
            Console.ReadKey();
        }
    }
}
