﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace do_While循环
{
    class Program
    {
        static void Main(string[] args)
        {
            /*do-while循环.
             * 语法：
             * do
             *   {
             *      循环体；
             *    }while（循环条件）；
             * 执行过程：程序首先会执行do中的循环体，执行完成后，去判断do-while循环的循环条件，
             * 如果成立，则继续执行do中的循环体，如果不成立，则跳出do-while循环。
             * 特点：先循环，再判断，最少执行一遍循环体.
             */


            //明天小兰就要登台演出了，老师说再把明天的演出的歌曲唱一遍，
            //如果满意，小兰就可以回家了，否则就需要再练习一遍，直到老师满意为止.（y/n）

            //循环体：小兰唱一遍 问老师满意吗？老师回答
            //循环条件：老师不满意
            //Console.WriteLine("老师我唱的您满意吗");
            //string answer = Console.ReadLine();
            //while(answer=="no")
            //{
            //    Console.WriteLine("老师，我再唱一遍，你满意吗？");
            //    answer = Console.ReadLine();
            //}
            //遇见这种首先执行一遍循环体，拿着执行后的结果再去判断是否执行循环的循环.
            //我们推荐使用do-while循环.
            //Console.ReadKey();

            //----------do_while----------
            //string answer= "";
            //do
            //{
            //    Console.WriteLine("老师，我唱的您满意吗？");
            //    answer = Console.ReadLine();
            //} while (answer=="no");
            //Console.WriteLine("OK,放假回家~~");
            //Console.ReadKey();


            //要求用户输入用户名和密码，只要不是admin、888888就一直提示用户名或密码错误，请重新输入。

            //string ad = "";
            //string pwd   = "";
            //do
            //{
            //    Console.WriteLine("请输入用户名");
            //    ad = Console.ReadLine();
            //    Console.WriteLine("请输入密码");
            //    pwd = Console.ReadLine();
            //} while (ad!="admin"||pwd!="888888");
            //Console.WriteLine("登陆成功！");
            //Console.ReadKey();


            






        }
    }
}
