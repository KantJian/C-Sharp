﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace c枚举的练习
{
    public enum Sesons
    {
        春,
        夏,
        秋,
        冬,
    }
    public enum QQState
    {
        OnLine,
        OffLine,
        Leave,
        Busy,
        QMe,
    }
    class Program
    {
        static void Main(string[] args)
        {
            Sesons s = Sesons.冬;
            QQState State = QQState.Busy;
        }
    }
}
