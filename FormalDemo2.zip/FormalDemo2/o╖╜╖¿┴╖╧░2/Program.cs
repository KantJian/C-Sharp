﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace o方法练习2
{
    class Program
    {
        static void Main(string[] args)
        {
            //还记得学习循环时做的那道题吗？只允许用户输入y或n，请改成方法
            Console.WriteLine("请输入y或n");
            string result = Console.ReadLine();
            char res = Program.GetResult(result);
            Console.WriteLine(res);
            Console.ReadKey();
        }

        /// <summary>
        /// 判断用户输入的为y或n
        /// </summary>
        /// <param name="s">用户输入的值</param>
        /// <returns>返回y或n</returns>
        public static char GetResult(string s)
        {
            while (true)
            {
                try
                {
                    char res = Convert.ToChar(s);
                    if (res == 'y' || res == 'n')
                    {
                        return res;
                    }
                    else
                    {
                        Console.WriteLine("输入错误，请输入y或n");
                        s = Console.ReadLine();
                    }
                }
                catch
                {
                    Console.WriteLine("输入错误，请输入y或n");
                    s = Console.ReadLine();
                }
            }
        }



    }
}
