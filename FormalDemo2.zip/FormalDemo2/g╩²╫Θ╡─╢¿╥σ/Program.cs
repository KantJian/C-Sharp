﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace g数组的定义
{
    class Program
    {
        static void Main(string[] args)
        {
            //数组
            //一次性存储多个相同类型的变量。
            //语法：
            //数组类型[] 数组名=new 数组类型[数组长度]；
            int[] nums = new int[10];
            //数组的声明方式
            int[] numsTwo = { 1, 2, 3, 4, 5, 6 };       //推荐用nums 和numsTwo两种命名方式

            //////int[] numsThree = new int[3] { 1, 2, 3 }; 这两种不用记*/*

            //////int[] numsFour = new int[] { 1, 2, 3, 4, 5 };

            //string[] str = new string[10];

            ////null 和""  不是一个意思 null是没开空间 ""是开了空间的
            //bool[] bools = new bool[10];

            //Console.ReadKey();

            //当你写了上面这样一行代码之后，就在内存中开辟
            //了连续的10块空间，我们管每一个块称之为这个数
            //组的元素。
            //数组的长度一但固定了，就不能再改变了。
            //如果你想要访问到数组中某一块元素，需要通过这个元素的下标或者索引去访问。
            //nums[0] = 1;
            //nums[1] = 2;
            //nums[2] = 3;
            //nums[3] = 4;
            //nums[4] = 5;
            //nums[5] = 6;
            //nums[6] = 7;
            //nums[7] = 8;
            //nums[8] = 9;
            //nums[9] = 10;
            //我们通过一个循环给数组赋值，同样，也通过一个循环对数组进行取值
            //for (int i = 0; i < nums.Length; i++)
            //{
            //    nums[i] = i;
            //}

            //for (int i = 0; i < nums.Length; i++)
            //{
            //    Console.WriteLine(nums[i]);
            //}
            //Console.ReadKey();





        }
    }
}
