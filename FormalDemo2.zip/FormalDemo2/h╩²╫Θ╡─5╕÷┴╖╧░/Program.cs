﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace h数组的5个练习
{
    class Program
    {
        static void Main(string[] args)
        {
            #region 练习1
            //练习1：从一个整数数组中取出最大的整数，最小整数，总和，平均值
            //声明一个int类型的数组 并且随意的赋初值
            //int[] nums= { 1,2,3,4,5,6,7,8,9,};
            //声明两个变量用来存储最大值和最小值
            //int max = nums[0];
            //int min = nums[0];
            //int sum = 0;
            ////循环的让数组中的每个元素跟我的最大值、最小值进行比较
            //for (int i = 0; i < nums.Length; i++)
            //{
            //    //关于在循环中nums[i]的理解方式
            //    //1.代表数组中当前循环到的元素
            //    //2.代表数组中的每个元素
            //    //如果数组中当前循环到的这个元素 比我的max还要大，则把当前这个元素赋值给我的max
            //    if(nums[i]>max)
            //    {
            //        max = nums[i];
            //    }
            //    if(nums[i]<min)
            //    {
            //        min = nums[i];
            //    }
            //    sum += nums[i];
            //}
            //Console.WriteLine("这个数组最大值是{0}，最小值是{1}，总和是{2}，平均值是{3}",max,min,sum,sum/nums.Length);
            //Console.ReadKey(); 
            #endregion

            #region 练习2
            //练习2.计算一个整数数组的所有元素的和
            //同第一题 
            #endregion

            #region 练习3

            //练习3.数组里面都是人的名字，分割成：例如：老杨|老苏|老邹...
            //(老杨，老苏，老邹，老虎，老牛，老蒋，老王，老马)

            //string[] names = { "老杨", "老苏", "老邹", "老虎", "老牛", "老马" };
            //string str = null;
            //for (int i = 0; i < names.Length-1; i++)
            //{
            //    str += names[i] + "|";
            //}
            //Console.WriteLine(str+names[names.Length-1]);
            //Console.ReadKey(); 
            #endregion

            #region 练习4
            //练习4.将一个整数数组的每一个元素进行如下的处理：
            //如果元素是正数则将这个位置的元素的值加1,
            //如果元素是负数则将这个位置的元素的值减1，如果元素是0，则不变。
            //int[] nums = { -1, 0, 1, 2, 3, 4, 5, 6, -7, 8, 9, -10 };
            //for (int i = 0; i < nums.Length; i++)
            //{
            //    if (nums[i] > 0)
            //    {
            //        nums[i] += 1;
            //    }
            //    else if (nums[i] < 0)
            //    {
            //        nums[i] -= 1;
            //    }
            //    else
            //    {
            //        nums[i]=0;
            //    }
            //    Console.WriteLine(nums[i]);
            //}
            //Console.ReadKey(); 
            #endregion

            #region 练习5
            //练习5.将一个字符串数组的元素的顺序进行反转。{"我","是","好人"}{ "好人","是","我"}。
            //第i个和第Length-i-1个进行交换。
            string[] str = { "我", "是", "好人", "a", "df", "5" };
            for (int i = 0; i < str.Length / 2; i++)
            {
                string temp = str[i];
                str[i] = str[str.Length - 1 - i];
                str[str.Length - 1 - i] = temp;
            }
            for (int i = 0; i < str.Length; i++)
            {
                Console.WriteLine(str[i]);
            }
            Console.ReadKey(); 
            #endregion
        }
    }
}
