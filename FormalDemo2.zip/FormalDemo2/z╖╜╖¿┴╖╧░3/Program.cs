﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace z方法练习3
{
    class Program
    {
        static void Main(string[] args)
        {
            //写一个方法，用来判断用户输入的数字不是质数
            //再写一个方法要求用户只能输入数字 输入有误就一直让用户输入
            while (true)
            {
                Console.WriteLine("请输入一个数字，我们将判断你输入的是否是质数");
                string strNumber = Console.ReadLine();
                int number = GetNumber(strNumber);
                bool b = IsPrime(number);
                Console.WriteLine(b);
                Console.ReadKey();
            }
        }
        /// <summary>
        /// 只能让用户输入数字
        /// </summary>
        /// <param name="strNumber">用户输入</param>
        /// <returns>返回数字</returns>
        public static int GetNumber(string strNumber)
        {
            while (true)
            {
                try
                {
                    int number = Convert.ToInt32(strNumber);
                    return number;
                }
                catch
                {
                    Console.WriteLine("请重新输入");
                    strNumber = Console.ReadLine();
                }
            }
        }
        /// <summary>
        /// 判断是否为质数
        /// </summary>
        /// <param name="number">数</param>
        /// <returns>是否为质数</returns>
        public static bool IsPrime(int number)
        {
            if (number < 2)
            {
                return false;
            }
            else //>=2
            {
                //让这个数字从2除 除到自身的前一位
                for (int i = 2; i < number; i++)
                {
                    if(number%i==0)
                    {
                        return false;
                    }
                }
                return true;
            }
        }


    }
}
