﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace q方法练习4
{
    class Program
    {
        static void Main(string[] args)
        {
            //计算输入数组的和：int Sum(int[] values)
            int[] values= { 1, 2, 3, 4, 5, 6, 7, 8, 9,10 };
            int sumNumber = Program.Sum(values);
            Console.WriteLine(sumNumber);
            Console.ReadKey();
        }
        /// <summary>
        /// 计算数组的和
        /// </summary>
        /// <returns>返回数组总和</returns>
        public static int Sum(int[] a)
        {
            int sumNumbers = 0;
            for (int i = 0; i < a.Length; i++)
            {

                sumNumbers += a[i];
               
            }
            return sumNumbers;
        }

    }
}
