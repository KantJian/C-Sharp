﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace z方法练习5
{
    class Program
    {
        static void Main(string[] args)
        {
            //请将字符串数组{"中国","美国","巴西","澳大利亚","加拿大"}中的内容反转
            string[] names = { "中国", "美国", "巴西", "澳大利亚", "加拿大" };
            //string[] newNames = Test(names);         
            Test(names);
            for (int i = 0; i < names.Length; i++)
            {
                Console.WriteLine(names[i]);
            }
            Console.ReadKey();
        }

        //public static string[] Test(string[] names)
        public static void Test(string[] names)
        {
            for (int i = 0; i < names.Length / 2; i++)
            {
                string temp = names[i];
                names[i] = names[names.Length - 1 - i];
                names[names.Length - 1 - i] = temp;
            }
           // return names;
        }

    }
}
