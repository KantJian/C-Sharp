﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace u_params可变参数
{
    class Program
    {
        static void Main(string[] args)
        {
            //int[] s = { 99, 88, 77 };
            //Test("张三", 99,88,77,66,55); //把这几个数当作数组中的元素
            //Console.ReadKey();

            //求任意长度数组的最大值 整数类型的
            int[] nums = { 1, 2, 3, 4, 5 };
            int sum = GetSum(8,9);
            Console.WriteLine(sum);
            Console.ReadKey();
        }

        public static int GetSum(params int[] n)
        {
            int sum = 0;
            for (int i = 0; i < n.Length; i++)
            {
                sum += n[i];
            }
            return sum;
        }
        
        
        
        
        //params参数
        //将实参列表中跟可变参数数组类型一致的元素都当作数组的元素去处理
        public  static void Test(string name,int id,params int[] score) // params可变参数必须是形参列表的最后一个  
        {
            int sum = 0;
            
            for (int i = 0; i < score.Length; i++)
            {
                sum += score[i];
            }
            Console.WriteLine("{0}这次考试的总成绩是{1}，学号是{2}",name,sum,id);
        }

    }
}
