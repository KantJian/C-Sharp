﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace z方法练习6
{
    class Program
    {
        static void Main(string[] args)
        {
            //写一个方法 计算圆的面积和周长 面积是pi*r*r 周长是 2*pi*r
            double r = 5;
            double perimeter;
            double area;
            GetPerimeterArea(r, out perimeter, out area);
            Console.WriteLine(perimeter);
            Console.WriteLine(area);
            Console.ReadKey();
        }

        public static void GetPerimeterArea(double r, out double perimeter, out double area)
        {
            perimeter = 2 * 3.14 * r;
            area = 3.14 * r * r;
        }

    }
}
