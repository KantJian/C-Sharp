﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace t_ref参数
{
    class Program
    {
        static void Main(string[] args)
        {
            //ref参数
            //能够将一个变量带入一个方法中进行改变，改变完成后，再将改变后的值带出方法。
            //好处就是不需要再写返回值了
            //ref参数要求在方法外必须为其赋值，而方法内可以不赋值
            double salary = 5000;
            //double s=JiangJin(salary);
            JiangJin(ref salary);
            Console.WriteLine(salary);
            Console.ReadKey();
        }

        //public static double JiangJin(double s)
        public static void JiangJin(ref double s)
        {
            s += 500;
            //return s;
        }

        public static void FaKuan(double s)
        {
            s -= 500;
        }

    }
}
