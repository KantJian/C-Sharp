﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace p方法练习3
{
    class Program
    {
        static void Main(string[] args)
        {
            //查找两个整数中的最大值：int Max（int n1,int n2）
            int n1 = 10;
            int n2 = 20;
            int max = Program.GetMax(n1, n2);
            Console.WriteLine(max);
            Console.ReadKey();
        }
        /// <summary>
        /// 找出两个数的最大值
        /// </summary> 
        /// <param name="n1">第一个整数</param>
        /// <param name="n2">第二个整数</param>
        /// <returns>返回最大值</returns>
        public static int GetMax(int n3, int n4)
        {
            int max = n3 > n4 ? n3 : n4;
            return max;
        }

    }
}
