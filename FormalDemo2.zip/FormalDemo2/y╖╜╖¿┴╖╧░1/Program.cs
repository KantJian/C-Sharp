﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace y方法练习1
{
    class Program
    {
        static void Main(string[] args)
        {
            //用方法来实现：有一个字符串数组：
            //{“马龙”，“迈克尔乔丹”，“蒂姆邓肯”。“麦尔古拜木合塔尔”}
            //请输出最
            string[] names = { "马龙","迈克尔乔丹","蒂姆邓肯","麦尔古拜木合塔尔"};
            string max = GetLongest(names);
            Console.WriteLine(max);
            Console.ReadKey();
        }
        /// <summary>
        /// 求一个字符串数组中最长的元素
        /// </summary>
        /// <param name="s">字符串数组</param>
        /// <returns>最长元素</returns>
        public static string GetLongest(string[] s)
        {
            string max = s[0];
            for (int i = 0; i < s.Length; i++)
            {
                if (s[i].Length > max.Length)
                {
                    max = s[i];
                }
            }
            return max;
        }

    }
}
