﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace b枚举
{
    //将枚举声明到命名空间的下面，类的外面，表示这个命名空间下，所有的类都可以使用这个枚举。
    //枚举
    //语法：
    //[public] enum 枚举名
    //{
    //  值1，
    //  值2，
    //  值3，
    //  ······
    //}
    
    public enum Gender//声明了一个枚举 Gender
    {
        男,
        女,//最后一个逗号可加可不加
    }
    class Program
    {
        static void Main(string[] args)
        {
            //枚举
            //语法：
            //[public] enum 枚举名
            //{
            //  值1，
            //  值2，
            //  值3，
            //  ······
            //}
            //public：访问修饰符。公开的公共的，哪都可以访问。
            //enum：关键字，声明枚举的关键字
            //枚举名：要符合Pascal命名规范
            //枚举可以规范我们的开发
            //枚举就是一个变量类型，int-double，string decimal. 只是枚举声明、赋值的方式跟那些普通的变量类型不一样。

            //为什么会有枚举这个东东？
            //xx大学管理系统
            //姓名 性别 年龄 系别 年级
            //性别
            //char gender = '男';
            //string s1 = "female";
            //string ss1 = "爷们";

            //变量类型 变量名=值；
            //int n = 10;
            //Gender gender = Gender.男;

           
            











        }
    }
}
