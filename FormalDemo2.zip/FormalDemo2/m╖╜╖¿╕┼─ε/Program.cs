﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace m方法概念
{
    class Program
    {
        public static void Main(string[] args)
        {
            //比较两个数字的大小 返回最大值
            int n1 = 10;
            int n2 = 20;
            int max=Program.Getmax(n1,n2);//实参  个数和类型与形参一致
            //Program 在这个方法里可以省略因为与main函数在同一个类
            Console.WriteLine(max);
            Console.ReadKey();
        }
        /// <summary>
        /// 计算两个整数之间的最大值 并且返回最大值
        /// </summary>
        /// <param name="n1">第一个整数</param>
        /// <param name="n2">第二个整数</param>
        /// <returns>返回的最大值</returns>
        public static int Getmax(int n1,int n2)//形参      *不管是形参还是实参都是在内存中开辟空间的*
        {
            int max=n1 > n2 ? n1 : n2;
            return max;
        }
    }
}
