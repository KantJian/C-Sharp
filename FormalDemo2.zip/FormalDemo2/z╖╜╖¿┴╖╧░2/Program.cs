﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace z方法练习2
{
    class Program
    {
        static void Main(string[] args)
        {
            ///用方法来实现：请计算出一个整型数组的平均值。保留两位小数
            int[] numbers = { 1, 2, 7 };
            double avg=GetAvg(numbers);
            string s = avg.ToString("0.00");
            avg = Convert.ToDouble(s);
            Console.WriteLine(avg);
            //Console.WriteLine("{0:0.00}",avg);
            //Console.WriteLine(avg);
            Console.ReadKey();
        }
        /// <summary>
        /// 计算出一个整型数组的平均值
        /// </summary>
        /// <param name="nums">整数数组</param>
        /// <returns>整数数组的平均值</returns>
        public static double GetAvg(int[] nums)
        {
            double sum = 0;
            for (int i = 0; i < nums.Length; i++)
            {
                sum += nums[i];
            }
            return sum / nums.Length;
        }

    }
}
