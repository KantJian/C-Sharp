﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace z方法练习9
{
    class Program
    {
        static void Main(string[] args)
        {
            //将一个字符串数组输出为|分割的形式，比如“梅西|卡卡|麦子”（用方法来实现此功能）
            string[] names = { "梅西", "卡卡", "麦子" };
            string str = ProcwssString(names);
            Console.WriteLine(str);
            Console.ReadKey();
        }

        public static string ProcwssString(string[] names)
        {
            string str = null;
            for (int i = 0; i < names.Length-1; i++)
            {
                str += names[i] + "|";
            }
            return str + names[names.Length - 1];
        }

    }
}
