﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace d枚举和int以及string类型之间的转换
{

    public enum QQState
    {
        ONLine = 1,
        OffLine,
        Leave,
        Busy,
        QMe
    }
    public enum Gender
    {
        男,
        女
    }
    class Program
    {
        static void Main(string[] args)
        {
            #region 将枚举类型强转成int类型
            //QQState state = QQState.ONLine;
            ////枚举类型默认可以跟int类型相互转换 枚举类型跟int类型是兼容的
            //int n = (int)state;
            //Console.WriteLine(n);
            //Console.WriteLine((int)QQState.OffLine);
            //Console.WriteLine((int)QQState.Leave);
            //Console.WriteLine((int)QQState.Busy);
            //Console.WriteLine((int)QQState.QMe);
            //Console.ReadKey(); 
            #endregion

            #region 将int类型强转为枚举类型
            //int n1 = 3;

            //QQState state = (QQState)n1;
            //Console.WriteLine(state);
            //Console.ReadKey(); 
            #endregion

            #region 将枚举类型转换成字符串类型
            //所有的类型都能够转换成string类型
            //int n1 = 10;
            //double n1 = 3.14;
            //decimal n1 = 5000m;
            //string s = n1.ToString();
            //Console.WriteLine(s);
            //Console.ReadLine();

            //QQState state = QQState.ONLine;
            //string s = state.ToString();
            //Console.WriteLine(s);
            //Console.ReadKey(); 
            #endregion

            #region 将字符串类型转换为枚举类型
            //string s = "2";
            ////将s转换成枚举类型
            ////Convert.ToInt32();  int.Parse() int.TryParse()
            ////调用Parse（）方法的目的就是为了让它帮助我们将一个字符串转换成对应的枚举类型
            //QQState state = (QQState)Enum.Parse(typeof(QQState), s);
            //Console.WriteLine(state);
            //Console.ReadKey(); 
            #endregion
            //我们可以将一个枚举类型的变量跟int类型和string类型相互转换。
            //枚举类型默认是跟int类型相互兼容,所以可以通过强制转换的语法互相转换。
            //当转换一个枚举中没有的值的时候，不会抛异常,而是直接将数字显示出来。

            //枚举同样也可以跟string类型相互转换，如果将枚举类型转换成string类型,则直接调用ToString（）
            //如果将字符串转换成枚举类型则需要下面这样一行代码：
            //      （要转换的枚举类型）Enum.Parse（typeof（要转换的枚举类型）,“要转换的字符串”）;
            //如果转换的字符串是数字，则就算枚举中没有，也不会抛异常。
            //如果转换的字符串是文本,如果枚举中没有,则会抛出异常。


            //--------枚举练习------------
            //提示用户选择一个在线状态，我们接收，并将用户的输入转换成枚举类型。
            //再次打印到控制台中
            Console.WriteLine("请选择您的qq在线状态 1--OnLine 2--OffLine 3--Leave 4-Busy 5--QMe");
            string input = Console.ReadLine();
            switch (input)
            {
                case "1": QQState s1 = (QQState)Enum.Parse(typeof(QQState), input);
                    Console.WriteLine("您选择的状态是{0}",s1);
                    break;
                case "2":QQState s2=(QQState)Enum.Parse(typeof(QQState), input);
                    Console.WriteLine("您选择的状态是{0}",s2);
                    break;
                case "3": QQState s3 = (QQState)Enum.Parse(typeof(QQState), input);
                    Console.WriteLine("您选择的状态是{0}", s3);
                    break;
                case "4":QQState s4 = (QQState)Enum.Parse(typeof(QQState), input);
                    Console.WriteLine("您选择的状态是{0}", s4);
                    break;
                case "5":QQState s5 = (QQState)Enum.Parse(typeof(QQState), input);
                    Console.WriteLine("您选择的状态是{0}", s5);
                    break;
            }
            Console.ReadKey();







        }
    }
}
