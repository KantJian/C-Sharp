﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace a复杂数据类型_常量
{
    class Program
    {
        static void Main(string[] args)
        {
            //常量
            //声明的常量的语法：
            //const 变量类型 变量名=值；
            //

            int number = 10;
            number = 20;//体现了变量可以被重新赋值

            const int numberTwo = 50;//常量 不能够被重新赋值
            //numberTwo = 90;  赋值号左边必须是变量







        }
    }
}
