﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace k方法的调用
{
    class Program
    {
        //字段 属于类的字段
        public static int _number = 10;


        static void Main(string[] args)
        {
            //int b=10;
            int a = 3;
            int res=Test(a);
            Console.WriteLine(res);
            //Console.WriteLine(_number);
            Console.ReadKey();
        }

        public static int Test(int a)
        {

            a = a + 5;
            return a;

            //我们在Main函数中，调用Test（）函数，我们管Main（）函数称之为调用者，
            //管Test（）函数称之为被调用者。
            //如果被调用者想要得到调用者的值：
            //1).传递参数
            //2).使用静态字段来模拟全局变量。(c#中并没有全局变量这个东西)
            //如果调用者想要得到被调用者的值:
            //1).返回值

        }

        public static void TestTwo()
        {
           // Console.WriteLine(_number);
        }


    }
}
