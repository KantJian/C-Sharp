﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace e结构
{
    public struct Person
    {
        public string _name; //字段
        public int _age;
        public Gender _gender;
    }

    public enum Gender
    {
        男,
        女
    }
    class Program
    {
        static void Main(string[] args)
        {
            //xx大学管理系统
            //姓名 性别 年龄 系别 年级  5000人  就要 20000个变量
            //string zsName = "张三";
            //int zsAge = 21;
            //char zsGender = '男';
            //int zsGrade = 3;

            //结构
            //可以帮助我们一次性声明多个不同类型的变量。
            //语法：
            //[public] struct 结构名       //public可以省略结构名按照P 命名首字母大写
            /*{
             *     成员;//先理解为变量，其实是字段。
             * }
             * 变量在程序运行期间只能存储一个值，而字段可以存储多个值。
             * 字段前加一个下划线与变量区分
            */

            Person zsPerson;
            zsPerson._name = "张三";
            zsPerson._age = 21;
            zsPerson._gender = Gender.男;

            Person lsPerson;
            lsPerson._name = "李四";
            lsPerson._age = 22;
            lsPerson._gender = Gender.女;

            Console.WriteLine(zsPerson._name);
            Console.WriteLine(lsPerson._name);
            Console.ReadKey();



        }
    }
}
