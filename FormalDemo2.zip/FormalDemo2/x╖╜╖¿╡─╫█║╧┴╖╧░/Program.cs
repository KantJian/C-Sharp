﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace x方法的综合练习
{
    class Program
    {
        static void Main(string[] args)
        {
            //提示用户输入两个数字  计算这两个数字之间所有整数的和
            //1.用户只能输入数字
            //2.计算两个数字之间和
            //3.要求第一个数字必须比第二个数字小 就重新输入
            Console.WriteLine("请输入第一个数字");
            string strNumberOne = Console.ReadLine();
            int num1 = IsNumber(strNumberOne);
            Console.WriteLine("请输入第二个数字");
            string strNumberTwo = Console.ReadLine();
            int num2 = IsNumber(strNumberTwo);
            //判断第一个数字小于第二个数字
            IsTwoMax(ref num1,ref num2);
            //求和
            int sum = IsSum(num1, num2);
            Console.WriteLine(sum);
            Console.ReadKey();
        }
        /// <summary>
        /// 判断输入的是否为整数数字
        /// </summary>
        /// <param name="s1">输入的整数数字</param>
        /// <returns>返回整数数字</returns>
        public static int IsNumber(string s1)
        {
            while (true)
            {
                try
                {
                    int nums = Convert.ToInt32(s1);
                    return nums;
                }
                catch
                {
                    Console.WriteLine("输入的不是整数数字，请重新输入");
                    s1 = Console.ReadLine();
                }
            }

        }
        /// <summary>
        /// 计算两个数字之间的整数和
        /// </summary>
        /// <param name="n1">第一个整数</param>
        /// <param name="n2">第二个整数</param>
        /// <returns>返回两个数字之间的整数和</returns>
        public static int IsSum(int n1, int n2)
        {
            int sum = 0;
            for (int i = n1; i <= n2; i++)
            {
                sum += i;
            }
            return sum;
        }
        /// <summary>
        /// 判断输入的第二个数大于第一个数
        /// </summary>
        /// <param name="n1">输入的第一个数</param>
        /// <param name="n2">输入的第二个数</param>
        /// <returns></returns>
        public static void IsTwoMax(ref int n1,ref int n2)
        {
            while (true)
            {
                if (n1 < n2)
                {
                    //符合题意
                    return;
                }
                else
                {
                    Console.WriteLine("输入的第二个数字必须大于第一个数字！请重新输入第一个数字");
                    string s1 = Console.ReadLine();
                    //调用IsNumber
                    n1 = IsNumber(s1);
                    Console.WriteLine("请重新输入第二个数字");
                    string s2 = Console.ReadLine();
                    n2 = IsNumber(s2);
                }
            }
        }

    }
}
