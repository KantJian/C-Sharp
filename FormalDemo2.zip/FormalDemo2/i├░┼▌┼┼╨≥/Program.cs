﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace i冒泡排序
{
    class Program
    {
        static void Main(string[] args)
        {
            //冒泡排序：就是将一个数组中的元素按照从大到小或者从小到大的顺序进行排列。
            int[] nums = {  8, 7, 6, 5, 4, 3,10, 2, 1, 0 };
            //第一趟比较：8 7 6 5 4 3 2 1 0 9 交换了9次 i=0 j=9
            //第二趟比较：7 6 5 4 3 2 1 0 8 9 交换了8次 i=1 j=8
            //第三趟比较：6 5 4 3 2 1 0 7 8 9 交换了7次 i=2 j=7
            //第四堂比较：5 4 3 2 1 0 6 7 8 9 交换了6次 i=3 j=6
            //第五趟比较：4 3 2 1 0 5 6 7 8 9 交换了5次
            //第六堂比较：3 2 1 0 4 5 6 7 8 9 交换了4次
            //第七趟比较：2 1 0 3 4 5 6 7 8 9 交换了3次
            //第八趟比较：1 0 2 3 4 5 6 7 8 9 交换了2次
            //第九趟比较：0 1 2 3 4 5 6 7 8 9 交换了1次

            //Array.Sort(nums);//只能针对数组做一个升序的排列

            //Array.Reverse(nums);//对数组进行反转

            //for (int i = 0; i < nums.Length-1; i++) //用来控制比较的趟数
            //{
            //    for (int j = 0; j <nums.Length-1-i;j++)
            //    {
            //        if(nums[j]>nums[j+1])
            //        {
            //            int temp = nums[j];
            //            nums[j] = nums[j + 1];
            //            nums[j + 1] = temp;  
            //        }
            //    }
            //}
            for (int i = 0; i < nums.Length; i++)
            {
                Console.WriteLine(nums[i]);
            }
            Console.ReadKey();




        }
    }
}
