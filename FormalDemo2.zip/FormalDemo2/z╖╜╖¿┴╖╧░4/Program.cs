﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace z方法练习4
{
    class Program
    {
        static void Main(string[] args)
        {
            //接收输入后判断其等级并显示出来。
            //判断依据如下：等级={优 （90～100分）；良（80～89）；}
            Console.WriteLine("请输入考试成绩");
            int score = Convert.ToInt32(Console.ReadLine());

            string level = GetLevel(score);
            Console.WriteLine(level);
            Console.ReadKey();
        }

        public static string GetLevel(int score)
        {
            string level = "";
            switch (score / 10)
            {
                case 10:
                case 9: level = "优"; break;
                case 8: level = "良"; break;
                case 7: level = "中"; break;
                case 6: level = "差"; break;
                default:
                    level = "不及格";
                    break;
            }
            return level;
        }

    }
}
