﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace n_值传递和引用传递
{
    class Program
    {
        static void Main(string[] args)
        {
            //值类型：int double char decimal bool enum struct
            //引用类型：string 数组 自定义类 集合 object 接口

            //值传递和引用传递
            //int n1 = 10;
            //int n2 = n1;
            //n2 = 20;
            //Console.WriteLine(n1);
            //Console.WriteLine(n2);
            //Console.ReadKey();
            //值类型在复制的时候，传递的是这个值的本身。            

            //Person p1 = new Person();
            //p1.Name = "张三";
            //Person p2 = p1;
            //p2.Name = "李四";
            //p1.Name = "abc";

            //Console.WriteLine(p2.Name);
            //Console.ReadKey();
            //引用类型在复制的时候，传递的是对这个对象的引用。


            //Person p = new Person();
            //p.Name = "张三";
            //Test(p);
            //Console.WriteLine(p.Name);
            //Console.ReadKey();

            //字符串不可变性，开辟了不同的空间 引用类型中字符串的特殊要记得*-* 改变一个另外一个不受影响 重新开辟了空间
            //string s1 = "张三";
            //string s2 = s1;
            //s2 = "李四";
            //Console.WriteLine(s1);
            //Console.WriteLine(s2);
            //Console.ReadKey();


            int number = 10;
            TestTwo(ref number);
            Console.WriteLine(number);
            Console.ReadKey();

        }

        public static void TestTwo(ref int n)
        {
            n += 10;
        }
        
        //Person pp=p;
        public static void Test(Person pp)//不管是实参还是形参都在内存中开辟了空间
        {
            Person p = pp;
            p.Name = "李四";
        }

    }



    public class Person
    {
        private string _name;
        public string Name
        {
            get { return _name; }
            set { _name = value; }
        }

    }
}
