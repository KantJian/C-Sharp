﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;

namespace f_StreamReader和StreamWriter
{
    class Program
    {
        static void Main(string[] args)
        {
            //使用StreamReader来读取一个文本文件
            //using (StreamReader sr = new StreamReader(@"C:\Users\Marguba\Desktop\222.txt",Encoding.Default))
            //{
            //    while(!sr.EndOfStream)
            //    {
            //        Console.WriteLine(sr.ReadLine());
            //    }
            //}
            //Console.ReadKey();


            //使用StreamWrite来写入一个文本文件
            //using (StreamWriter sw = new StreamWriter(@"C: \Users\Marguba\Desktop\222.txt"))
            //{
            //    sw.Write("覆盖？");
            //}
            //Console.WriteLine("OK");
            //Console.ReadKey();


        }
    }
}
