﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace u_接口特点
{
    class Program
    {
        static void Main(string[] args)
        {
            //为了多态。接口不能被实例化
            //也就是说接口不能new（不能创建对象）
            IFlyable fly = new Bird();
            fly.Fly();
            Console.ReadKey();
        }
    }

    public class Person:IFlyable
    {
        public void Fly() //只要一个类继承了一个接口，这个类就必须实现这个接口中所有的成员
        {
            Console.WriteLine("人类在飞");
        }

    }

    public class Bird : IFlyable
    {
        public void Fly()
        {
            Console.WriteLine("鸟在飞");
        }
    }

    public interface IFlyable
    {
        //不允许有访问修饰符 默认为public 不能修改
        //方法、自动属性
        void Fly();
    }
}
