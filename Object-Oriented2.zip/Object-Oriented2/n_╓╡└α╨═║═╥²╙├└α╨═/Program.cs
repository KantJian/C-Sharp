﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace n_值类型和引用类型
{
    class Program
    {
        static void Main(string[] args)
        {
            //值类型：int double char decimal bool enum struct
            //引用类型：string 数组 自定义类 集合 object 接口

        }
    }
}
