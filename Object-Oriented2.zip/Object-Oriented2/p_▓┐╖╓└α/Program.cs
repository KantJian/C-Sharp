﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace p_部分类
{
    class Program
    {
        static void Main(string[] args)
        {
            //partial 部分类
        }
    }

    //同时都能进行编程
    public partial class Person
    {
        private string _name;
    }

    public partial class Person
    {
       // _name
    }
}
