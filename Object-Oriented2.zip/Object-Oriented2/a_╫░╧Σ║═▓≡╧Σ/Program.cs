﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace a_装箱和拆箱
{
    class Program
    {
        static void Main(string[] args)
        {
            //装箱、拆箱
            //装箱：就是将值类型转换为引用类型。
            //拆箱：就是将引用类型转换为值类型。

            //int n = 10;
            //object o = n;//装箱
            //int nm = (int)o;//拆箱

            ////ArrayList list = new ArrayList(); //1
            //List<int> list = new List<int>();//2
            ////这个循环发生了100万次装箱操作
            //Stopwatch sw = new Stopwatch();
            ////00:00:00.0438963 1 装箱
            ////00:00:00.0156843 2 无任何拆箱装箱
            //sw.Start();
            //for (int i = 0; i < 1000000; i++)
            //{
            //    list.Add(i);
            //}
            //sw.Stop();
            //Console.WriteLine(sw.Elapsed);
            //Console.ReadKey();


            ////这个地方没有发生任意类型的装箱或拆箱
            //string str = "123";
            //int n = Convert.ToInt32(str);

            //看两种类型是否发生了装箱或者拆箱，要看，这两种类型是否存在继承关系。
            //存在继承关系只是有可能


            int n = 10;
            IComparable i = n;//装箱



        }
    }
}
