﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace i_抽象类
{
    class Program
    {
        static void Main(string[] args)
        {
            //狗狗会叫 猫咪也会叫
            //2)、抽象类
            //当父类中的方法不知道如何去实现的时候，可以考虑将父类写成抽象类，将方法写成抽象方法

            /*抽象类特点：
             * 1、抽象成员必须标记为abstract，并且不能有任何实现。
             * 2、抽象成员必须在抽象类中。
             * 3、抽象类不能被实例化。
             * 4、子类继承抽象类对象后，必须把父类中的所有抽象成员都重写。
             *    （除非子类也是一个抽象类，则可以不重写）
             * 5、抽象成员的访问修饰符不能是private。
             * 6、在抽象类中可以包含实例成员。
             * 7、抽象类是有构造函数的，虽然不能被实例化。
             * 8、如果父类的抽象方法中有参数，那么，继承这个抽象父类的子类在重写父类的方法的时候必须传入对应的参数。
             *    如果抽象父类的抽象方法中有返回值，那么子类在重写这个抽象方法的时候，也必须要传入返回值。
             * ===========================================================================================================
             * 如果父类中的方法有默认的实现，并且父类需要被实例化，这时可以考虑将父类定义成一个普通类，用虚方法来实现多态。
             * 如果父类中的方法没有默认的实现，父类也不需要被实例化，则可以将该类定义为抽象类。
            */
            Animal a = new Cat();//Dog();
            a.Bark();

            Console.ReadKey();

        }
    }


    public abstract class Animal
    {
        public abstract void Bark();//没有方法体 
    }

    public class Dog : Animal
    {
        public override void Bark()
        {
            Console.WriteLine("狗狗汪汪叫");
        }
    }

    public class Cat : Animal
    {
        public override void Bark()
        {
            Console.WriteLine("猫咪喵喵叫");
        }
    }
}
