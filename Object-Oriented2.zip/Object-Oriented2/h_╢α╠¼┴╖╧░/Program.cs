﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace h_多态练习
{
    class Program
    {
        static void Main(string[] args)
        {
            //真的鸭子嘎嘎叫 木头鸭子吱吱叫 橡皮鸭子唧唧叫
            RealDuck r1 = new RealDuck();
            WoodDuck w1 = new WoodDuck();
            RubberDuck rd = new RubberDuck();
            RealDuck[] duck = { r1, w1, rd };
            for (int i = 0; i < duck.Length; i++)
            {
                duck[i].Bark();
            }
            Console.ReadKey();
        }
    }

    //public class Duck
    //{
    //    private string _name;
    //    public string Name
    //    {
    //        get { return _name; }
    //        set { _name = value; }
    //    }
    //    public Duck(string name)
    //    {
    //        this.Name = name;
    //    }
    //    public virtual void Bark()
    //    {
    //        Console.WriteLine("我是鸭子，我瓜瓜叫");
    //    }
    //}

    public class RealDuck 
    {
        public virtual void Bark()
        {
            Console.WriteLine("我是真鸭子，我嘎嘎叫");
        }
    }

    public class WoodDuck : RealDuck
    {
       
        public override void Bark()
        {
            Console.WriteLine("我是木头鸭子，我吱吱叫");
        }
    }

    public class RubberDuck : RealDuck
    {
        public override void Bark()
        {
            Console.WriteLine("我是橡皮鸭子，我唧唧叫");
        }

    }
}
