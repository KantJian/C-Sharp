﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace h_多态练习2
{
    class Program
    {
        static void Main(string[] args)
        {
            //经理十一点打卡 员工九点打卡 程序猿不打卡
            //Employee emp = new Employee();
            //Manager mg = new Manager();
            //Programmer pm = new Programmer();
            //Employee[] emps = { emp, mg, pm };
            //for (int i = 0; i < emps.Length; i++)
            //{
            //    emps[i].DaKa();
            //}
            //Console.ReadKey();


          
        }
    }

   


    //    public class Employee
    //    {
    //        public virtual void DaKa()
    //        {
    //            Console.WriteLine("九点打卡");
    //        }
    //    }

    //    public class Manager : Employee
    //    {
    //        public override void DaKa()
    //        {
    //            Console.WriteLine("经理11点打卡");
    //        }
    //    }

    //    public class Programmer : Employee
    //    {
    //        public override void DaKa()
    //        {
    //            Console.WriteLine("程序猿不打卡");
    //        }
    //    }
}
