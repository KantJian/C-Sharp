﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace i_字符串的方法_1_
{
    class Program
    {
        static void Main(string[] args)
        {
            string s1 = "张三";
            string s2 = "张三";
            Console.ReadKey();
        }
    }
}
