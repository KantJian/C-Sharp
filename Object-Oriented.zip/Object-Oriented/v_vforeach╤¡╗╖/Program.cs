﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace v_vforeach循环
{
    class Program
    {
        static void Main(string[] args)
        {
            //for 和 foreach
            //foreach循环效率高于for

            //int[] nums = { 1, 2, 3, 4, 5, 6, 76, 7, 8, 23 };
            //for (int i = 0; i < nums.Length; i++)
            //{
            //    Console.WriteLine(nums[i]);
            //}
            //Console.WriteLine("===================");
            //foreach (var item in nums)
            //{
            //    Console.WriteLine(item);
            //}

            //Console.ReadKey();

            //Stopwatch sw = new Stopwatch();
            ////00:00:06.3044081
            //sw.Start();
            //for (int i = 0; i < 1000000000; i++)
            //{

            //}
            //sw.Stop();
            //Console.WriteLine(sw.Elapsed);
            //Console.ReadKey();

            //Stopwatch sw = new Stopwatch();
            //int[] nums = new int[1000];
            //sw.Start();
            //foreach (var item in nums)
            //{

            //}
            //sw.Stop();
            //Console.WriteLine(sw.Elapsed);
            //Console.ReadKey();



        }
    }
}
