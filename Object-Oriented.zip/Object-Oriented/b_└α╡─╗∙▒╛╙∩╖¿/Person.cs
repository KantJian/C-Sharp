﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace b_类的基本语法
{
    public class Person
    {
       private string _name;

        public string Name
        {
            get { return _name; }
            set { _name = value; }
        }

        private int _age;
        public int Age
        {
            get { return _age; }
            set { 
                  if (value < 0 || value > 100)
                {
                    value = 0;
                }
                
                _age = value; }
        }
     
        public char Gender
        {
            get { 
                 if (_gender != '男' && _gender != '女')
                {
                    return _gender = '男';
                }
                
                return _gender; }
            set { _gender = value; }
        }
        char _gender;


        public void CHLSS()
        {
            Console.WriteLine("我叫{0}，我今年{1}岁了，我是{2}生，我可以吃喝拉撒睡哟～～～～～",this.Name,this.Age,this.Gender);
        }

    }
}
