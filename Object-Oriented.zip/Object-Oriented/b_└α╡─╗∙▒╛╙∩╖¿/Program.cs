﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace b_类的基本语法
{
    class Program
    {
        static void Main(string[] args)
        {
            //类
            //语法：
            //[public] class 类名
            //{
            //    字段；
            //    属性；//属性的作用就是保护字段、对字段的赋值和取值进行限定。
            //    方法；
            //}

            //写好了一个类之后，我们需要创建这个类的对象，
            //那么，我们管创建这个类的对象过程称之为类的实例化。
            //使用关键字 new.

            ////创建Person类的对象
            /// //string s;
            //Person sunQuan;//自定义类
            Person sunQuan = new Person();//类的实例化
            sunQuan.Name = "孙全";
            sunQuan.Age = 23;
            sunQuan.Gender = '男';
            sunQuan.CHLSS();           
            Console.ReadKey();       //这一段代码用来描述孙全这个对象

            //类是不占内存的 而对象是占内存的
           

            //属性
            //属性的作用就是保护字段、对字段的赋值和取值进行限定。
            //属性的本质就是两个方法，一个叫get（）一个叫set（）
            //既有get（）也有set（）我们称之为可读可写属性。
            //只有get（）没有set（）我们称之为只读属性
            //没有get（）只有set（）我们称之为只写属性

            //Field字段
            //Method方法
            //Property属性

            //*****字段就是女人 属性就是男人  男人保护女人

            //访问修饰符
            //public：公开的公共的，在哪都能访问。
            //private：私有的，只能在当前类的内部进行访问，出了这个类就访问不到了。


        }
    }
}
