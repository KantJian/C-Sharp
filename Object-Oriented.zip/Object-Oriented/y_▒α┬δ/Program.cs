﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace y_编码
{
    class Program
    {
        static void Main(string[] args)
        {
            /*  美国人 发明了计算机  a-z 0-9
             * 最早用ASC编码 128
             * 欧洲国家也开始用计算机 除了有 a-z 0-9 音标上也有不一样
             * ASCⅡ 256
             *  我国 最早推出编码GB2312 只包含简体字
             *  香港 台湾 五大硬件厂商自己重新做个编码 Big5 繁体字
             * 
             * 美国人发现计算机编码太多了 每个国家都不一样
             * 出了一个统一的比较全的编码 unicode 编码全 但是解析慢
             * UTF-8 针对web的一个编码格式
             * 编码：将字符串以怎样的形式保存为二进制
             *
             * 乱码：产生乱码的原因就是保存的这个文件采用的编码，
             *       跟你打开这个文件所采用的编码格式不一样，
            */
            
        }
    }
}
