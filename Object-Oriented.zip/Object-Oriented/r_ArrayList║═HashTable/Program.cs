﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace r_ArrayList和HashTable
{
    class Program
    {
        static void Main(string[] args)
        {
            //ArrayList集合
            //创建了一个集合对象
            ArrayList list = new ArrayList();
            //集合：很多数据的一个集合
            //数组：长度不可变、类型单一
            //集合的好处：长度可以任意改变 类型随便
            list.Add(1);
            list.Add(3.14);
            list.Add(true);
            list.Add("张三");
            list.Add('男');
            list.Add(5000m);
            //list.Add(new int[] { 1, 2, 3, 4, 5, 6, 7, 8, 9 });
            Person p = new Person();
            list.Add(p);
            //list.Add(list);
            //添加集合用AddRange
            list.AddRange(new int[] {1,2,3,4,5,6,7,8,9});
            list.AddRange(list);

            //list.Clear();//清空所有元素
            //list.Remove(true);//删除单个元素，写谁就删谁
            //list.RemoveAt(0);//根据下标去删除元素
            //list.RemoveRange(0, 3);//根据下标去移除一定范围的元素
            //list.Sort();//升序排列
            //list.Reverse();//反转
            //list.Insert(1, "插入的");//插入单个元素
            //list.InsertRange(0, new string[] { "张三", "李四" });//在指定的位置插入一个集合
            //bool b=list.Contains(1);//判断是否包含某个指定的元素
            //Console.WriteLine(b);
            list.Add("颜世伟");
            if (!list.Contains("颜世伟"))
            {
                list.Add("颜世伟");
            }
            else
            {
                Console.WriteLine("我们已经有这个屌丝了");
            }

            for (int i = 0; i < list.Count; i++)
            {
                if (list[i] is Person)
                {
                    ((Person)list[i]).SayHello();
                }
                //else if (list[i] is int[])
                //{
                //    for (int j = 0; j < ((int[])list[i]).Length; j++)
                //    {
                //        Console.WriteLine(((int[])list[i])[j]);
                //    }
                //}
                else
                {
                    Console.WriteLine(list[i]);
                }
                
                
                // Console.WriteLine(list[i]);

            }
            Console.ReadKey();
        }
    }

    public class Person
    {
        public void SayHello()
        {
            Console.WriteLine("我是人类");
        }
    }
}
