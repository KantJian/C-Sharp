﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace p_里氏转换练习
{
    class Program
    {
        static void Main(string[] args)
        {
            //创建10个对象 通过一个循环 去调用他们各自打招呼的方法
            //Student s = new Student();
            //Person p = new Person();
            //ShaiGuo sg = new ShaiGuo();

            Person[] pers = new Person[10];
            Random r = new Random();
            for (int i = 0; i < pers.Length; i++)
            {
                int rNumber = r.Next(1, 6);
                switch (rNumber)//1-5
                {
                    case 1:
                        pers[i] = new Student();
                        break;
                    case 2:
                        pers[i] = new Teacher();
                        break;
                    case 3:
                        pers[i] = new Meilv();
                        break;
                    case 4:
                        pers[i] = new ShuaiGuo();
                        break;
                    case 5:
                        pers[i] = new MeiNv();
                        break;
                }
            }
            for (int i = 0; i < pers.Length; i++)
            {
                //pers[i].PersonSayHi();
                if (pers[i] is Student)
                {
                    ((Student)pers[i]).StudentSayHi();
                }
                else if (pers[i] is Teacher)
                {
                    ((Teacher)pers[i]).TeacherSayHi();
                }
                else if (pers[i] is Meilv)
                {
                    ((Meilv)pers[i]).MeiLvSayHi();
                }
                else if (pers[i] is ShuaiGuo)
                {
                    ((ShuaiGuo)pers[i]).ShuaiGuoSayHi();
                }
                else if (pers[i] is MeiNv)
                {
                    ((MeiNv)pers[i]).MeiNvSayHi();
                }
                else
                {
                    pers[i].PersonSayHi();
                }

            }
            Console.ReadKey();
        }
    }

    //方便练习不再添加新类.
    public class Person
    {
        public void PersonSayHi()
        {
            Console.WriteLine("我是人类");
        }
    }

    public class Student : Person
    {
        public void StudentSayHi()
        {
            Console.WriteLine("我是学生");
        }
    }

    public class Teacher : Person
    {
        public void TeacherSayHi()
        {
            Console.WriteLine("我是老师");
        }
    }
    public class Meilv : Person
    {
        public void MeiLvSayHi()
        {
            Console.WriteLine("我是镁铝");
        }
    }
    public class ShuaiGuo : Person
    {
        public void ShuaiGuoSayHi()
        {
            Console.WriteLine("我是帅锅");
        }
    }
    public class MeiNv : Person
    {
        public void MeiNvSayHi()
        {
            Console.WriteLine("我是美女");
        }
    }
}
