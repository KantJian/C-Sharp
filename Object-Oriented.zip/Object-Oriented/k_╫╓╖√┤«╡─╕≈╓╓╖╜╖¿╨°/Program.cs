﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace k_字符串的各种方法续
{
    class Program
    {
        static void Main(string[] args)
        {
            //string str="国家关键人物老赵";
            //if (str.Contains("老赵"))//Contains包含
            //{
            //    str=str.Replace("老赵", "**");//Replace替换
            //}
            //Console.WriteLine(str);
            //Console.ReadKey();

            ////Substring 截取字符串
            //string str = "今天天气好晴朗，处处好风光";
            //str = str.Substring(1,2); //从指定的索引1开始 包含此索引 截取2个
            //Console.WriteLine(str);
            //Console.ReadKey();

            //string str = "今天天气好晴朗，处处好风光";
            //if (str.StartsWith("今天")) //EndsWith
            //{
            //    Console.WriteLine("是的");
            //}
            //else
            //{
            //    Console.WriteLine("不是");
            //}
            //Console.ReadKey();


            //string str = "今天天气好晴朗，天天处处好风光";
            //int index = str.IndexOf('天',2);  //找这个字符在字符串中第一次出现的位置
            //Console.WriteLine(index);
            //Console.ReadKey();

            //string str = "今天天气好晴朗，处处好风光";
            //int index = str.LastIndexOf('天');  //找这个字符在字符串中最后一次出现的位置
            //Console.WriteLine(index);
            //Console.ReadKey();


            //LastIndexOf Substring
            //string path = @"c:\a\b\阿c\d\e\f\g\fd\阿三大苏打就.wav";
            //int index = path.LastIndexOf("\\"); //转义符 两个\\表示一个\
            //path = path.Substring(index+1);
            //Console.WriteLine(path);
            //Console.ReadKey();


            //string str = "                 hahahah            ";
            ////str=str.Trim();
            ////str = str.TrimStart();
            //str = str.TrimEnd();
            //Console.Write(str);
            //Console.ReadKey();


            //string str = "aasdas";
            //if (string.IsNullOrEmpty(str))
            //{
            //    Console.WriteLine("是的");
            //}
            //else
            //{
            //    Console.WriteLine("不是");
            //}
            //Console.ReadKey();


            string[] names = { "张三", "李四", "王五" ,"赵六","田七"};
            //张三|李四|王五|赵六|田七
            string strNew = string.Join("|", names);
            Console.WriteLine(strNew);
            Console.ReadKey();




        }
    }
}
