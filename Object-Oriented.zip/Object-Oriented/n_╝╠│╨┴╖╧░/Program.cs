﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace n_继承练习
{
    class Program
    {
        static void Main(string[] args)
        {
            //写一个Reporter类和一个Programmer类，Driver类，他们都有一个打招呼的方法，
            //不同的是Reporter打招呼是说“大家好，我叫XX，我的爱好是XXX”，
            //Programmer的打招呼的方法是说“大家好，我叫XX，我今年XX岁了，我已经工作XX年了”？
            //摄影家类Photographer

            //记者：我是记者 我的爱好是偷拍 我的年龄是34 我是一个男狗仔
            //司机：我叫舒马赫 我的年龄是43 我是男人 我的驾龄是 23年
            //程序员：我叫孙全 我的年龄是23 我是男生 我的工作年限是3 年


            Reporter rep = new Reporter("狗仔", 34, '男', "偷拍");

            rep.ReporterSayHello();

            Programmer pro = new Programmer("程序猿", 23, '男', 3);

            pro.ProgrammerSayHello();

            Console.ReadKey();
        }
    }
}
