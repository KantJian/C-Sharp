﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace v_var推断类型
{
    class Program
    {
        static void Main(string[] args)
        {
            //var:根据值能够推断出来类型
            //C# 是一门强类型语言：在代码当中，必须对每一个变量的类型有一个明确的定义
            //var n =15;
            //var n2 = "张三";
            //var n3 = 3.14;
            //var n4 = 5000m;
            //var n5 = true;
            //var n6 = '男';
            //Console.WriteLine(n.GetType());
            //Console.WriteLine(n2.GetType());
            //Console.WriteLine(n3.GetType());
            //Console.WriteLine(n4.GetType());
            //Console.WriteLine(n5.GetType());
            //Console.WriteLine(n6.GetType());
            //Console.ReadKey();

            //var input; //在声明var时必须赋值
            //input = "张三";






            //js是一门弱类型语言
            //12 3.14 true "asdaf"  'c'  都用var 不需要明确定义
        }
    }
}
