﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace q_protected访问修饰符
{
    class Program
    {
        static void Main(string[] args)
        {
            //publi private
            Person p = new Person();
           //protected
           //受保护的：可以在当前类的内部以及该类的子类中访问
        }
    }

    public class Person
    {
        //private string _name;
       protected string _name;
        public string Name
        {
            get { return _name; }
            set { _name = value; }
        }
    }

    public class Student : Person
    {
        public void Test()
        {
            
        }
    }
}
