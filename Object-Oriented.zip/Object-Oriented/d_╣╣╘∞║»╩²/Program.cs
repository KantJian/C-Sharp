﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace d_构造函数
{
    class Program
    {
        static void Main(string[] args)
        {
            Student s = new Student("张三", 100, 100, 100);
            Console.ReadKey();

            //Student zsStudent = new Student("张三",18,'男',100,100,100);
            ////zsStudent.Name = "张三";
            ////zsStudent.Age = 18;
            ////zsStudent.Gender = '男';
            ////zsStudent.Chinese = 100;
            ////zsStudent.Math = 100;
            ////zsStudent.English = 100;
            //zsStudent.SayHello();
            //zsStudent.ShowScore();

            //Student xlStudent = new Student("小兰", 16, '女', 50, 50, 50);
            ////xlStudent.Name = "小兰";
            ////xlStudent.Age = 16;
            ////xlStudent.Gender = '女';
            ////xlStudent.Chinese = 50;
            ////xlStudent.Math = 50;
            ////xlStudent.English = 50;
            //xlStudent.SayHello();
            //xlStudent.ShowScore();
            //Console.ReadKey();
            //构造函数（构造方法）
            //作用：帮助我们初始化对象（给对象的每个属性依次的赋值）
            //构造函数是一个特殊的方法：
            //1)、构造函数没有返回值，连void也不能写。
            //2)、构造函数的名称必须跟类名一样。
            //创建对象的时候会执行构造函数
            //构造函数是可以有重载的
            //类当中会有一个默认的无参数的构造函数，当你写了一个新的构造函数之后，不管是有参数的还是无参数的，
            //那个默认的无参数的构造函数都被干掉了。

            //new关键字
            //Person zsPerson=new Person();
            //new帮助我们做了3件事儿：
            //1、在内存中开辟一块空间
            //2、在开辟的空间中创建对象
            //3、调用对象的构造函数进行初始化对象
        }
    }
}
