﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace v_foreach循环
{
    class Program
    {
        static void Main(string[] args)
        {
        }
    }
}
