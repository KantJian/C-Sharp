﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace f_面向对象继承命名空间
{
    class Program
    {
        static void Main(string[] args)
        {

            //    File
            //    List<int> list = new List<int>();
            //A--->ProjectA---顾客类
            //B--->ProjectB---顾客类
            //C--->ProjectC---顾客类
            //namespace（命名空间），用于解决类重名问题，可以看做“类的文件夹”

            //命名空间
            //可以认为类是属于命名空间的。
            //如果在当前项目中没有这个类的命名空间，需要我们手动的导入这个类所在的
            //命名空间
            //1)、用鼠标去点
            //2)、alt+shift+F10
            //3)、记住命名空间，手动的去引用

            //在一个项目中引用另一个项目的类
            //1、添加引用
            //2、引用命名空间

            


        }
    }
}
