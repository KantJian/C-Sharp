﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace o_里氏转换
{
    class Program
    {
        static void Main(string[] args)
        {
            //里氏转换
            //1)、子类可以赋值给父类:如果有一个地方需要一个父类作为参数，我们可以给一个子类代替
            //Student s = new Student();
            //Person p = s;
            Person p = new Student();

            //string str=string.Join("|", new string[] { "1", "2", "3", "4" });
            //Console.WriteLine(str);
            //Console.ReadKey();

            //2)、如果父类中装的是子类对象，那么可以讲这个父类强转为子类对象。


            //Student ss = (Student)p;
            //ss.StudentSayHello();
            //Console.ReadKey();

            //is的用法
            //if (p is Student)
            //{
            //    Student ss = (Student)p;
            //    ss.StudentSayHello();
            //}
            //else
            //{
            //    Console.WriteLine("转换失败");
            //}
            //Console.ReadKey();

            //as的用法
            Student t = p as Student;
            t.StudentSayHello();
            Console.ReadKey();

            //子类对象可以调用父类中的成员，但是父类对象永远都只能调用自己的成员。

            //is:表示类型转换，如果能够转换成功，则返回一个true，否则返回一个false.
            //as:表示类型转换，如果能够转换，则返回对应的对象，否则返回一个null.


        }
    }
}
