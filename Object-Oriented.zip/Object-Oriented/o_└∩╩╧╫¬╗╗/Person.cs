﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace o_里氏转换
{
    public class Person
    {
       public void PersonSayHello()
        {
            Console.WriteLine("我是父亲");
        }
    }
}
