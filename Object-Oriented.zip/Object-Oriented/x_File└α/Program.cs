﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace x_File类
{
    class Program
    {
        static void Main(string[] args)
        {
            //创建一个文件
            //File.Create(@"C:\Users\Marguba\Desktop\new.txt");
            //Console.WriteLine("创建成功");
            //Console.ReadKey();

            //删除一个文件
            //File.Delete(@"")

            //1024byte=1kb
            //1024kb=1M
            //1024M=1G
            //1024G=1T
            //1024T=1PT

            //复制一个文件
            //File.Copy(@"****code.txt",@"***new.txt")

            //byte[] buffer = File.ReadAllBytes(@"C:\Users\Marguba\Desktop\123.txt");
            ////将字节数组中的每一个元素都要按照我们指定的编码格式解码成字符串
            ////UTF-8 GB2312 GBK ASCⅡ Unicode
            //string s=Encoding.Default.GetString(buffer);
            //Console.ReadKey();

            //没有这个文件的话 会给你创建一个 有的话 会给你覆盖掉
            //string str = "今天天气好晴朗处处好风光";
            ////需要将字符串转换成字节数组
            //byte[] buffer = Encoding.Default.GetBytes(str);
            //File.WriteAllBytes(@"C:\Users\Marguba\Desktop\123.txt");
            //Console.WriteLine("写入成功");
            //Console.ReadKey();

            //string[] contents = File.ReadAllLines(@"C:\Users\Marguba\Desktop\123.txt", Encoding.Default);
            //foreach (string item in contents)
            //{
            //    Console.WriteLine(item);
            //}
            //Console.ReadKey();

            //string str= File.ReadAllText(@"C:\Users\Marguba\Desktop\123.txt", Encoding.Default);
            //Console.WriteLine(str);
            //Console.ReadKey();

            //File.WriteAllBytes......

            //绝对路径和相对路径
            //绝对路径：通过给定的这个路径直接能在我的电脑中找到这个文件
            //相对路径：文件相对于应用程序的路径。
            //结论：我们在开发中应该去尽量的使用相对路径。


        }
    }
}
