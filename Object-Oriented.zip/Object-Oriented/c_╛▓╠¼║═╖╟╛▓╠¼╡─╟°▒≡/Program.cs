﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace c_静态和非静态的区别
{
    class Program
    {
        static void Main(string[] args)
        {
            //静态和非静态的区别
            //1)、在非静态类中，既可以有实例成员，也可以有静态成员。
            //2)、在调用实例成员的时候，需要使用对象名.实例成员；
            //3)、在调用静态成员的时候，需要使用类名.静态成员名；
            //总结：静态成员必须使用类名去调用，而实例成员使用对象名调用。
            //      静态函数中，只能访问静态成员，不允许访问实例成员。
            //      实例函数中，既可以使用静态成员，也可以使用实例成员。
            //      静态类中只允许有静态成员，不允许出现实例成员。
            //调用实例成员
            Person p = new Person();
            p.M1();//实例方法
            Person.M2();//静态方法
            //Student s = new Student();

            Console.WriteLine();
            Console.ReadKey();
            

            //使用：
            //1)、如果你想要你的类当做一个“工具类”去使用，这个时候可以考虑将类写成静态的
            //2)、静态类在整个项目中资源共享。
            //只有在程序全部结束之后，静态类才会释放资源。
            
            //堆 栈 静态存储区域

            //释放资源。GC Garbage Collection垃圾回收器


        }
    }
}
