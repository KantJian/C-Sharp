﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace j_字符串的各种方法
{
    class Program
    {
        static void Main(string[] args)
        {
            //练习一：随机输入你心中想到的一个名字，然后输出它的字符串长度  Length:可以得字符串的长度
            //Console.WriteLine("请输入你心中想的那个人的名字");
            //string name = Console.ReadLine();
            //Console.WriteLine("你心中想的人的名字的长度是{0}", name.Length);
            //Console.ReadKey();
            //字符串提供的各种方法
            //1)、Length：获得当前字符串中字符的个数
            //2)、lessonOne.ToUpper();将字符串转换成大写
            //3)、lessonOne.ToLower();将字符串转换成小写
            //4)、Equals(lessonTwo,StringComparison.OrdinalIgnoreCase) 比较两个字符串
            //5)、Split() 分割字符串，返回字符串类型的数组
            //6)、Substring() 截取字符串，在截取的时候包含要截取的那个位置
            //7)、IndexOf() 判断某个字符串在字符串中第一次出现的位置，如果没有返回-1
            //8)、LastIndexOf()判断某个字符串在字符串中最后出现的位置，如果没有返回-1
            //9)、StartWith() 判断以...开始
            //10)、EndWith()判断以...结束
            //11)、Replace()将字符串中某个字符串替换成一个新的字符串
            //12)、Contains()判断某个字符串是否包含指定的字符串
            //13()、Trim()去掉字符串中前后的空格
            //14()、TrimEnd()去掉字符串中结尾的空格
            //15()、TrimStart()去掉字符串的前面的空格
            //16()、string.IsNullOrEmpty()判断一个字符串是否为空或者为null
            //17()、string.Join()将数组按照指定的字符串连接，返回一个字符串

            //练习二：两个学员输入各自最喜欢的课程名称，判断是否一致，如果相等，则输出你们俩喜欢相同的课程。
            //如果不相同，则输出你们俩喜欢不相同的课程。
            //Console.WriteLine("请输入你喜欢的课程");
            //string lessonOne = Console.ReadLine();
            ////将字符串转换成大写\小写
            ////lessonOne = lessonOne.ToUpper();
            ////lessonOne = lessonOne.ToLower();
            //Console.WriteLine("请输入你喜欢的课程");
            //string lessonTwo = Console.ReadLine();
            ////lessonTwo = lessonTwo.ToUpper();
            ////lessonTwo = lessonTwo.ToLower();
            ////if (lessonOne == lessonTwo)
            //if(lessonOne.Equals(lessonTwo,StringComparison.OrdinalIgnoreCase))
            //{
            //    Console.WriteLine("你们俩喜欢的课程相同");
            //}
            //else
            //{
            //    Console.WriteLine("你们俩喜欢的课程不相同");
            //}
            //Console.ReadKey();


            //string s = "a b  dfd _  +  =  ,,,  fdf";
            ////分割字符串Split
            //char[] chs = {' ', '_', '+', '=', ',' };
            //string[] str = s.Split(chs,StringSplitOptions.RemoveEmptyEntries);
            //Console.ReadKey();

            //练习：从日期字符串（“2008-08-08”）中分析出年、月、日：2008年08月08日
            //让用户输入一个日期格式如2008-01-02 你输出你输入的日期为2008年1月2日

            string s = "2008-08-08";
            //char[] chs = {'-'};
            string[] date=s.Split(new char[] { '-'}, StringSplitOptions.RemoveEmptyEntries);
            Console.WriteLine("{0}年{1}月{2}日",date[0],date[1],date[2]);
            Console.ReadKey();

        }
    }
}
