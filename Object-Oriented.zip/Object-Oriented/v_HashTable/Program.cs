﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace v_HashTable
{
    class Program
    {
        static void Main(string[] args)
        {
            //HashTable 键值对集合     字典   孙    sun--孙 拼音找字 键找值
            //在键值对集合当中，我们是根据键去找值的。
            //键值对对象[键]=值
            //键不可以重复，值可以重复

            Hashtable ht = new Hashtable();
            ht.Add(1, "张三");
            ht.Add(2, true);
            ht.Add(3, '男');
            ht.Add(false, "错误的");
            ht[6] = "新来的";//这也是一种添加数据的方式
            ht[1] = "把张三干掉";
            ht.Add("abc", "cba");

            //abc--cba
            if (!ht.ContainsKey("abc"))
            {
                ht.Add("abc", "cba");
            }
            else
            {
                Console.WriteLine("包含这个键了！");
            }


            //ht.Clear();//移除集合中所有的元素
            //ht.Remove(3);

            //在键值对集合中，是根据键去找值的

            //Console.WriteLine(ht[1]);
            //Console.WriteLine(ht[2]);
            //Console.WriteLine(ht[3]);
            //Console.WriteLine(ht[false]);

            //for循环遍历不太可行
            //for (int i = 0; i < ht.Count; i++)
            //{
            //    Console.WriteLine(ht[i]);
            //}

            //foreach
            foreach (var item in ht.Keys)
            {
                Console.WriteLine("键是{0}----------值是{1}",item,ht[item]);
            }
            
            Console.ReadKey();

        }
    }
}
